import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { getLoginUrl } from "@/const";
import { LayoutDashboard, LogOut, PanelLeft, Users, Home as HomeIcon, Activity, Package, Clipboard, ShoppingCart, DollarSign, FileText, Settings, Syringe, Bell, TrendingUp, TrendingDown, Building2, ScrollText, Cog, ChevronRight, FlaskConical, Factory, Tag } from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from './DashboardLayoutSkeleton';
import { Button } from "./ui/button";
import LoginPage from "@/pages/Login";
import { ReminderNotifications } from "@/components/ReminderNotifications";
import { useIsMobile } from "@/hooks/useMobile";

type UserRole = "admin" | "farm_manager" | "accountant" | "sales_staff" | "production_worker" | "chicken_house_operator";

interface MenuItem {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  path: string;
  roles?: UserRole[]; // If undefined, accessible to all roles
  children?: MenuItem[]; // Submenu items
  indent?: boolean; // Whether this item is indented as a child
}

const menuItems: MenuItem[] = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/" },
  { icon: Activity, label: "Flocks", path: "/flocks", roles: ["admin", "farm_manager", "production_worker", "chicken_house_operator"] },
  { icon: HomeIcon, label: "Houses", path: "/houses", roles: ["admin", "farm_manager", "production_worker"] },
  { icon: TrendingUp, label: "Harvests", path: "/harvests", roles: ["admin", "farm_manager", "production_worker"] },
  { icon: Building2, label: "Processors", path: "/processors", roles: ["admin", "farm_manager"] },
  { icon: Package, label: "Crate Types", path: "/crate-types", roles: ["admin", "farm_manager", "production_worker"] },
  { icon: Clipboard, label: "Catch Operations", path: "/catch-operations", roles: ["admin", "farm_manager", "production_worker"] },
  { icon: Package, label: "Inventory", path: "/inventory", roles: ["admin", "farm_manager"] },
  { icon: Syringe, label: "Health", path: "/health", roles: ["admin", "farm_manager"] },
  { icon: Bell, label: "Reminder Templates", path: "/reminder-templates", roles: ["admin", "farm_manager"] },
  { icon: Users, label: "Customers", path: "/customers", roles: ["admin", "sales_staff"] },
  { icon: Package, label: "Suppliers", path: "/suppliers", roles: ["admin", "farm_manager", "accountant"] },
  { icon: ShoppingCart, label: "Sales", path: "/sales", roles: ["admin", "sales_staff"] },
  { icon: FileText, label: "Invoices", path: "/sales/invoices", roles: ["admin", "sales_staff"], indent: true },
  { icon: DollarSign, label: "Finance", path: "/finance", roles: ["admin", "accountant"] },
  { icon: TrendingDown, label: "Expenses", path: "/finance/expenses", roles: ["admin", "accountant"], indent: true },
  { icon: TrendingUp, label: "Cash Flow", path: "/finance/cash-flow", roles: ["admin", "accountant"], indent: true },
  { icon: FileText, label: "Reports", path: "/reports", roles: ["admin", "farm_manager", "accountant"] },
  { icon: ScrollText, label: "Audit Logs", path: "/audit-logs", roles: ["admin"] },
  { icon: Settings, label: "User Management", path: "/user-management", roles: ["admin"] },
  { icon: Settings, label: "Settings", path: "/settings/company", roles: ["admin"] },
  { icon: FlaskConical, label: "Feed Management", path: "/feed-management", roles: ["admin", "farm_manager"] },
  { icon: FlaskConical, label: "Formulations", path: "/feed-management/formulations", roles: ["admin", "farm_manager"], indent: true },
  { icon: Factory, label: "Mill Costs", path: "/feed-management/mill-costs", roles: ["admin", "farm_manager"], indent: true },
  { icon: Tag, label: "Customer Prices", path: "/feed-management/customer-pricing", roles: ["admin", "farm_manager"], indent: true },
];

const canAccessMenuItem = (item: MenuItem, userRole: string | undefined): boolean => {
  if (!item.roles) return true; // No role restriction, accessible to all
  if (!userRole) return false; // No user role, deny access
  return item.roles.includes(userRole as UserRole);
};

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 280;
const MIN_WIDTH = 200;
const MAX_WIDTH = 480;

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });
  const { loading, user } = useAuth();

  useEffect(() => {
    localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString());
  }, [sidebarWidth]);

  if (loading) {
    return <DashboardLayoutSkeleton />
  }

  if (!user) {
    return <LoginPage />;
  }

  return (
    <SidebarProvider
      style={
        {
          "--sidebar-width": `${sidebarWidth}px`,
        } as CSSProperties
      }
    >
      <DashboardLayoutContent setSidebarWidth={setSidebarWidth}>
        {children}
      </DashboardLayoutContent>
    </SidebarProvider>
  );
}

type DashboardLayoutContentProps = {
  children: React.ReactNode;
  setSidebarWidth: (width: number) => void;
};

function DashboardLayoutContent({
  children,
  setSidebarWidth,
}: DashboardLayoutContentProps) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const activeMenuItem = menuItems.find(item => item.path === location);
  const isMobile = useIsMobile();

  useEffect(() => {
    if (isCollapsed) {
      setIsResizing(false);
    }
  }, [isCollapsed]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;

      const sidebarLeft = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const newWidth = e.clientX - sidebarLeft;
      if (newWidth >= MIN_WIDTH && newWidth <= MAX_WIDTH) {
        setSidebarWidth(newWidth);
      }
    };

    const handleMouseUp = () => {
      setIsResizing(false);
    };

    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }

    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  return (
    <>
      <div className="relative" ref={sidebarRef}>
        <Sidebar
          collapsible="icon"
          className="border-r-0"
          disableTransition={isResizing}
        >
          <SidebarHeader className="h-16 justify-center">
            <div className="flex items-center gap-3 px-2 transition-all w-full">
              <button
                onClick={toggleSidebar}
                className="h-8 w-8 flex items-center justify-center hover:bg-sidebar-accent rounded-lg transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-ring shrink-0"
                aria-label="Toggle navigation"
              >
                <PanelLeft className="h-4 w-4 text-sidebar-foreground/70" />
              </button>
              {!isCollapsed ? (
                <div className="flex items-center gap-2 min-w-0">
                  <img 
                    src="https://files.manuscdn.com/user_upload_by_module/session_file/310419663029451273/oZXOcEyrNhCuGDCp.png" 
                    alt="AFGRO Poultry Manager" 
                    className="h-8 w-auto"
                  />
                  <div className="flex flex-col min-w-0">
                    <span className="font-semibold tracking-tight truncate text-sidebar-foreground text-sm leading-tight">
                      AFGRO
                    </span>
                    <span className="text-xs text-sidebar-foreground/70 truncate leading-tight">
                      Poultry Manager
                    </span>
                  </div>
                </div>
              ) : null}
            </div>
          </SidebarHeader>

          <SidebarContent className="gap-0">
            <SidebarMenu className="px-2 py-1">
              {menuItems
                .filter(item => canAccessMenuItem(item, user?.role))
                .map(item => {
                  const isActive = location === item.path || (item.path !== '/' && location.startsWith(item.path) && !item.indent);
                  const isExactActive = location === item.path;
                  return (
                    <SidebarMenuItem key={item.path}>
                      <SidebarMenuButton
                        isActive={isExactActive}
                        onClick={() => setLocation(item.path)}
                        tooltip={item.label}
                        className={`h-10 transition-all font-normal ${item.indent ? 'pl-8' : ''}`}
                      >
                        <item.icon
                          className={`h-4 w-4 ${isExactActive ? "text-sidebar-primary" : ""} ${item.indent ? 'opacity-70' : ''}`}
                        />
                        <span className={item.indent ? 'text-sm' : ''}>{item.label}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
            </SidebarMenu>
          </SidebarContent>

          <SidebarFooter className="p-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-3 rounded-lg px-1 py-1 hover:bg-sidebar-accent/50 transition-colors w-full text-left group-data-[collapsible=icon]:justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                  <Avatar className="h-9 w-9 border border-sidebar-border shrink-0">
                    <AvatarFallback className="text-xs font-medium bg-sidebar-accent text-sidebar-accent-foreground">
                      {user?.name?.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0 group-data-[collapsible=icon]:hidden">
                    <p className="text-sm font-medium truncate leading-none text-sidebar-foreground">
                      {user?.name || "-"}
                    </p>
                    <p className="text-xs text-sidebar-foreground/60 truncate mt-1.5">
                      {user?.email || "-"}
                    </p>
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem
                  onClick={logout}
                  className="cursor-pointer text-destructive focus:text-destructive"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Sign out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarFooter>
        </Sidebar>
        <div
          className={`absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-sidebar-primary/20 transition-colors ${isCollapsed ? "hidden" : ""}`}
          onMouseDown={() => {
            if (isCollapsed) return;
            setIsResizing(true);
          }}
          style={{ zIndex: 50 }}
        />
      </div>

      <SidebarInset>
        {isMobile && (
          <div className="flex border-b h-14 items-center justify-between bg-background/95 px-2 backdrop-blur supports-[backdrop-filter]:backdrop-blur sticky top-0 z-40">
            <div className="flex items-center gap-2">
              <SidebarTrigger className="h-9 w-9 rounded-lg bg-background" />
              <div className="flex items-center gap-3">
                <img 
                  src="https://files.manuscdn.com/user_upload_by_module/session_file/310419663029451273/oZXOcEyrNhCuGDCp.png" 
                  alt="AFGRO" 
                  className="h-6 w-auto"
                />
                <div className="flex flex-col gap-1">
                  <span className="tracking-tight text-foreground">
                    {activeMenuItem?.label ?? "Menu"}
                  </span>
                </div>
              </div>
            </div>
            <ReminderNotifications />
          </div>
        )}
        {!isMobile && (
          <div className="flex border-b h-14 items-center justify-end bg-background/95 px-4 backdrop-blur supports-[backdrop-filter]:backdrop-blur sticky top-0 z-40">
            <ReminderNotifications />
          </div>
        )}
        <main className="flex-1 p-4">{children}</main>
      </SidebarInset>
    </>
  );
}
