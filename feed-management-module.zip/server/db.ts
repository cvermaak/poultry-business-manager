import { eq, and, gte, lte, desc, asc, sql, or, like, inArray, isNotNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  houses,
  flocks,
  flockDailyRecords,
  vaccinationSchedules,
  healthRecords,
  mortalityRecords,
  feedFormulations,
  feedBatches,
  rawMaterials,
  rawMaterialTransactions,
  qualityControlRecords,
  customers,
  customerAddresses,
  salesOrders,
  salesOrderItems,
  invoices,
  invoiceItems,
  invoiceLineItems,
  payments,
  paymentAllocations,
  suppliers,
  itemTemplates,
  procurementSchedules,
  procurementOrders,
  procurementOrderItems,
  chartOfAccounts,
  generalLedgerEntries,
  inventoryItems,
  inventoryLocations,
  inventoryTransactions,
  documents,
  userActivityLogs,
  reminders,
  vaccines,
  stressPacks,
  flockVaccinationSchedules,
  flockStressPackSchedules,
  reminderTemplates,
  healthProtocolTemplates,
  harvestRecords,
  processors,
  catchSessions,
  companySettings,
  expenseCategories,
  expenses,
  cashFlowForecasts,
  cashFlowItems,
  millCosts,
  customerFeedPrices,
} from "../drizzle/schema";
import "../drizzle/relations";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL, {
        mode: "default",
        schema: {
          users,
          houses,
          flocks,
          flockDailyRecords,
          vaccinationSchedules,
          healthRecords,
          mortalityRecords,
          feedFormulations,
          feedBatches,
          rawMaterials,
          rawMaterialTransactions,
          qualityControlRecords,
          customers,
          customerAddresses,
          salesOrders,
          salesOrderItems,
          invoices,
          invoiceItems,
          invoiceLineItems,
          payments,
          paymentAllocations,
          suppliers,
          itemTemplates,
          procurementSchedules,
          procurementOrders,
          procurementOrderItems,
          chartOfAccounts,
          generalLedgerEntries,
          inventoryItems,
          inventoryLocations,
          inventoryTransactions,
          documents,
          userActivityLogs,
          reminders,
          vaccines,
          stressPacks,
          flockVaccinationSchedules,
          flockStressPackSchedules,
          reminderTemplates,
          healthProtocolTemplates,
          harvestRecords,
          processors,
          catchSessions,
          companySettings,
          expenseCategories,
          expenses,
          cashFlowForecasts,
          cashFlowItems,
          millCosts,
          customerFeedPrices,
        },
      });
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============================================================================
// USER MANAGEMENT
// ============================================================================

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? undefined;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listUsers() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(users).where(eq(users.isActive, true)).orderBy(asc(users.name));
}

export async function updateUserRole(userId: number, role: string) {
  const db = await getDb();
  if (!db) return false;

  await db.update(users).set({ role: role as any }).where(eq(users.id, userId));
  return true;
}

export async function logUserActivity(
  userId: number,
  action: string,
  entityType?: string,
  entityId?: number,
  details?: string,
  ipAddress?: string
) {
  const db = await getDb();
  if (!db) return;

  await db.insert(userActivityLogs).values({
    userId,
    action,
    entityType,
    entityId,
    details,
    ipAddress,
  });
}

// Email/Password Authentication Functions

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserByUsername(username: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserByEmailOrUsername(identifier: string) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users)
    .where(or(eq(users.email, identifier), eq(users.username, identifier)))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createEmailUser(data: {
  username: string;
  email: string;
  name: string;
  passwordHash: string;
  role: "admin" | "farm_manager" | "accountant" | "sales_staff" | "production_worker" | "chicken_house_operator";
  createdBy: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(users).values({
    username: data.username,
    email: data.email,
    name: data.name,
    passwordHash: data.passwordHash,
    loginMethod: "email",
    role: data.role,
    isActive: true,
    mustChangePassword: false,
    createdBy: data.createdBy,
  });

  return result[0].insertId;
}

export async function updateUserPassword(userId: number, passwordHash: string, mustChangePassword: boolean = false) {
  const db = await getDb();
  if (!db) return false;

  await db.update(users).set({ 
    passwordHash, 
    mustChangePassword,
    updatedAt: new Date() 
  }).where(eq(users.id, userId));
  return true;
}

export async function updateUserLastSignIn(userId: number) {
  const db = await getDb();
  if (!db) return false;

  await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, userId));
  return true;
}

export async function deactivateUser(userId: number) {
  const db = await getDb();
  if (!db) return false;

  await db.update(users).set({ isActive: false }).where(eq(users.id, userId));
  return true;
}

export async function activateUser(userId: number) {
  const db = await getDb();
  if (!db) return false;

  await db.update(users).set({ isActive: true }).where(eq(users.id, userId));
  return true;
}

export async function deleteUser(userId: number) {
  const db = await getDb();
  if (!db) return false;

  await db.delete(users).where(eq(users.id, userId));
  return true;
}

export async function updateUser(userId: number, data: {
  name?: string;
  email?: string;
  username?: string;
  role?: "admin" | "farm_manager" | "accountant" | "sales_staff" | "production_worker" | "chicken_house_operator";
}) {
  const db = await getDb();
  if (!db) return false;

  await db.update(users).set({ ...data, updatedAt: new Date() }).where(eq(users.id, userId));
  return true;
}

// ============================================================================
// HOUSE MANAGEMENT
// ============================================================================

export async function listHouses() {
  const db = await getDb();
  if (!db) return [];

  // Get houses with active flock count for status indication
  const houseList = await db.select().from(houses).where(eq(houses.isActive, true)).orderBy(asc(houses.name));
  
  // Get active/planned flock counts per house
  const flockCounts = await db
    .select({
      houseId: flocks.houseId,
      activeCount: sql<number>`SUM(CASE WHEN ${flocks.status} = 'active' THEN 1 ELSE 0 END)`,
      plannedCount: sql<number>`SUM(CASE WHEN ${flocks.status} = 'planned' THEN 1 ELSE 0 END)`,
    })
    .from(flocks)
    .where(inArray(flocks.status, ['active', 'planned']))
    .groupBy(flocks.houseId);
  
  const flockCountMap = new Map(flockCounts.map(fc => [fc.houseId, { active: fc.activeCount || 0, planned: fc.plannedCount || 0 }]));
  
  return houseList.map(house => ({
    ...house,
    activeFlockCount: flockCountMap.get(house.id)?.active || 0,
    plannedFlockCount: flockCountMap.get(house.id)?.planned || 0,
  }));
}

export async function getHouseById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(houses).where(eq(houses.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createHouse(data: Omit<typeof houses.$inferInsert, 'floorArea'>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Calculate floor area
  const length = Number(data.length);
  const width = Number(data.width);
  const floorArea = (length * width).toFixed(2);

  const result = await db.insert(houses).values({
    ...data,
    floorArea,
  });

  return result;
}

export async function updateHouse(id: number, data: Partial<typeof houses.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Recalculate floor area if dimensions changed
  if (data.length || data.width) {
    const house = await getHouseById(id);
    if (house) {
      const length = Number(data.length || house.length);
      const width = Number(data.width || house.width);
      data.floorArea = (length * width).toFixed(2) as any;
    }
  }

  await db.update(houses).set(data).where(eq(houses.id, id));
  return true;
}

export async function deleteHouse(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if house has any flocks (active or otherwise)
  const houseFlocks = await db.select().from(flocks).where(eq(flocks.houseId, id));
  if (houseFlocks.length > 0) {
    const activeFlocks = houseFlocks.filter(f => f.status === 'active' || f.status === 'planned');
    if (activeFlocks.length > 0) {
      throw new Error(`Cannot delete house: ${activeFlocks.length} active/planned flock(s) are using this house`);
    }
    // Soft delete - mark as inactive instead of hard delete if there are historical flocks
    await db.update(houses).set({ isActive: false }).where(eq(houses.id, id));
    return { softDeleted: true, message: "House marked as inactive due to historical flocks" };
  }

  // Hard delete if no flocks ever used this house
  await db.delete(houses).where(eq(houses.id, id));
  return { softDeleted: false, message: "House permanently deleted" };
}

export async function getHouseFlockCount(houseId: number) {
  const db = await getDb();
  if (!db) return { total: 0, active: 0, planned: 0 };

  const houseFlocks = await db.select().from(flocks).where(eq(flocks.houseId, houseId));
  return {
    total: houseFlocks.length,
    active: houseFlocks.filter(f => f.status === 'active').length,
    planned: houseFlocks.filter(f => f.status === 'planned').length,
  };
}

// ============================================================================
// FLOCK MANAGEMENT
// ============================================================================

export async function listFlocks(filters?: { status?: string; houseId?: number }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(flocks).$dynamic();

  if (filters?.status) {
    query = query.where(eq(flocks.status, filters.status as any));
  }
  if (filters?.houseId) {
    query = query.where(eq(flocks.houseId, filters.houseId));
  }

  const flockList = await query.orderBy(desc(flocks.placementDate));
  
  // Calculate actual current count for each flock based on mortality
  const flocksWithCalculatedCount = await Promise.all(
    flockList.map(async (flock) => {
      const dailyRecords = await getFlockDailyRecords(flock.id);
      const totalMortality = dailyRecords.reduce((sum, record) => 
        sum + (record.mortality || 0), 0
      );
      return {
        ...flock,
        currentCount: flock.initialCount - totalMortality,
      };
    })
  );
  
  return flocksWithCalculatedCount;
}

export async function getFlockById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(flocks).where(eq(flocks.id, id)).limit(1);
  if (result.length === 0) return undefined;
  
  const flock = result[0];
  
  // Calculate actual current count based on mortality from daily records
  const dailyRecords = await getFlockDailyRecords(flock.id);
  const totalMortality = dailyRecords.reduce((sum, record) => 
    sum + (record.mortality || 0), 0
  );
  
  return {
    ...flock,
    currentCount: flock.initialCount - totalMortality,
  };
}

export async function createFlock(data: typeof flocks.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(flocks).values(data);
  return result;
}

export async function updateFlock(id: number, data: Partial<typeof flocks.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(flocks).set(data).where(eq(flocks.id, id));
  
  // Update feed transition reminder dates if feed schedule changed
  const feedScheduleChanged = 
    data.starterToDay !== undefined ||
    data.growerFromDay !== undefined ||
    data.growerToDay !== undefined ||
    data.finisherFromDay !== undefined;
  
  if (feedScheduleChanged) {
    await updateFeedTransitionReminderDates(
      id,
      data.starterToDay ?? undefined,
      data.growerFromDay ?? undefined,
      data.growerToDay ?? undefined,
      data.finisherFromDay ?? undefined
    );
  }
  
  return true;
}

export async function deleteFlockVaccinationSchedules(flockId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(flockVaccinationSchedules).where(eq(flockVaccinationSchedules.flockId, flockId));
  return true;
}

export async function deleteFlockStressPackSchedules(flockId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(flockStressPackSchedules).where(eq(flockStressPackSchedules.flockId, flockId));
  return true;
}

export async function deleteFlockReminders(flockId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(reminders).where(eq(reminders.flockId, flockId));
  return true;
}

// ── Catch Plan ──────────────────────────────────────────────────────────────

export interface CatchPlanDay {
  day: number;           // 1-based catch day number
  targetBirds: number;  // birds to catch on this day
  targetCatchingWeight: number; // kg per bird on this day
  targetDeliveredWeight: number; // kg per bird delivered (after shrinkage)
  percentOfFlock: number; // % of total flock
  // Populated after the session is completed (rolling reforecast)
  actualBirds?: number;
  actualAvgCatchingWeight?: number;
  actualAvgDeliveredWeight?: number;
  completedAt?: string;
}

export interface CatchPlan {
  totalCatchDays: number;
  dailyGainKg: number;    // kg/day live weight gain
  shrinkagePct: number;   // e.g. 5.5
  overallTargetCatchingWeight: number;
  overallTargetDeliveredWeight: number;
  processorMaxCatchingWeight: number | null; // optional upper limit warning
  days: CatchPlanDay[];
  createdAt: string;
  lastUpdatedAt: string;
}

export async function saveCatchPlan(flockId: number, plan: CatchPlan) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(flocks)
    .set({ catchPlan: plan as any })
    .where(eq(flocks.id, flockId));
  return plan;
}

export async function getCatchPlanForFlock(flockId: number): Promise<CatchPlan | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select({ catchPlan: flocks.catchPlan }).from(flocks).where(eq(flocks.id, flockId)).limit(1);
  if (!result.length || !result[0].catchPlan) return null;
  return result[0].catchPlan as unknown as CatchPlan;
}

/**
 * Rolling reforecast: after a catch session completes, record actual results
 * and recalculate remaining days' targets so the house average stays on track.
 */
export async function reforecastCatchPlan(
  flockId: number,
  dayIndex: number,       // 0-based index of the completed day
  actualBirds: number,
  actualAvgCatchingWeight: number,
  completedAt: string
): Promise<CatchPlan | null> {
  const plan = await getCatchPlanForFlock(flockId);
  if (!plan) return null;

  // Record actual results for the completed day
  plan.days[dayIndex] = {
    ...plan.days[dayIndex],
    actualBirds,
    actualAvgCatchingWeight,
    actualAvgDeliveredWeight: actualAvgCatchingWeight * (1 - plan.shrinkagePct / 100),
    completedAt,
  };

  // Recalculate remaining days' targets
  const completedDays = plan.days.filter(d => d.actualBirds !== undefined);
  const remainingDays = plan.days.filter(d => d.actualBirds === undefined);

  if (remainingDays.length > 0) {
    // Calculate how much weight budget has been used by completed days
    const usedWeightBudget = completedDays.reduce(
      (sum, d) => sum + (d.actualBirds! * d.actualAvgCatchingWeight!), 0
    );
    const usedBirds = completedDays.reduce((sum, d) => sum + d.actualBirds!, 0);
    const totalBirds = plan.days.reduce((sum, d) => sum + d.targetBirds, 0);
    const totalWeightBudget = plan.overallTargetCatchingWeight * totalBirds;
    const remainingBudget = totalWeightBudget - usedWeightBudget;
    const remainingBirds = totalBirds - usedBirds;
    const remainingAvgTarget = remainingBirds > 0 ? remainingBudget / remainingBirds : plan.overallTargetCatchingWeight;

    // Distribute remaining budget across remaining days using daily gain stagger
    const midRemainingIdx = (remainingDays.length - 1) / 2;
    remainingDays.forEach((day, i) => {
      const offset = (i - midRemainingIdx) * plan.dailyGainKg;
      const newTarget = Math.round((remainingAvgTarget + offset) * 1000) / 1000;
      const dayIdx = plan.days.findIndex(d => d.day === day.day);
      plan.days[dayIdx] = {
        ...plan.days[dayIdx],
        targetCatchingWeight: newTarget,
        targetDeliveredWeight: Math.round(newTarget * (1 - plan.shrinkagePct / 100) * 1000) / 1000,
      };
    });
  }

  plan.lastUpdatedAt = new Date().toISOString();
  await saveCatchPlan(flockId, plan);
  return plan;
}

export async function updateFlockReminderDates(flockId: number, daysDiff: number) {
  const dbConn = await getDb();
  if (!dbConn) throw new Error("Database not available");
  const flockReminders = await dbConn.select().from(reminders).where(eq(reminders.flockId, flockId));
  for (const reminder of flockReminders) {
    const newDueDate = new Date(reminder.dueDate);
    newDueDate.setDate(newDueDate.getDate() + daysDiff);
    await dbConn.update(reminders)
      .set({ dueDate: newDueDate })
      .where(eq(reminders.id, reminder.id));
  }
  return true;
}

export async function deleteRemindersByTemplate(flockId: number, templateId: number) {
  const dbConn = await getDb();
  if (!dbConn) throw new Error("Database not available");
  await dbConn.delete(reminders)
    .where(and(eq(reminders.flockId, flockId), eq(reminders.templateId, templateId)));
  return true;
}

export async function getAppliedTemplatesForFlock(flockId: number) {
  const dbConn = await getDb();
  if (!dbConn) throw new Error("Database not available");
  const result = await dbConn.select({ templateId: reminders.templateId })
    .from(reminders)
    .where(and(eq(reminders.flockId, flockId), isNotNull(reminders.templateId)))
    .groupBy(reminders.templateId);
  return result.map(r => r.templateId).filter((id): id is number => id !== null);
}

export async function deleteFlock(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Delete all related records first (order matters for foreign key constraints)
  await db.delete(flockDailyRecords).where(eq(flockDailyRecords.flockId, id));
  await db.delete(reminders).where(eq(reminders.flockId, id));
  await db.delete(flockVaccinationSchedules).where(eq(flockVaccinationSchedules.flockId, id));
  await db.delete(flockStressPackSchedules).where(eq(flockStressPackSchedules.flockId, id));
  await db.delete(vaccinationSchedules).where(eq(vaccinationSchedules.flockId, id));
  await db.delete(healthRecords).where(eq(healthRecords.flockId, id));
  await db.delete(mortalityRecords).where(eq(mortalityRecords.flockId, id));
  await db.delete(procurementSchedules).where(eq(procurementSchedules.flockId, id));
  await db.delete(catchSessions).where(eq(catchSessions.flockId, id));
  // Set flockId to null for sales_order_items instead of deleting (preserve sales history)
  await db.update(salesOrderItems).set({ flockId: null }).where(eq(salesOrderItems.flockId, id));
  
  // Now delete the flock
  await db.delete(flocks).where(eq(flocks.id, id));
  return true;
}

export async function getFlockDailyRecords(flockId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(flockDailyRecords)
    .where(eq(flockDailyRecords.flockId, flockId))
    .orderBy(asc(flockDailyRecords.recordDate));
}

export async function createFlockDailyRecord(data: typeof flockDailyRecords.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(flockDailyRecords).values(data);
  return result;
}

export async function updateFlockDailyRecord(id: number, data: Partial<typeof flockDailyRecords.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(flockDailyRecords)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(flockDailyRecords.id, id));
  return { success: true };
}

export async function getFlockDailyRecordById(id: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.select().from(flockDailyRecords).where(eq(flockDailyRecords.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function deleteFlockDailyRecord(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(flockDailyRecords).where(eq(flockDailyRecords.id, id));
  return { success: true };
}

export async function getFlockVaccinationSchedule(flockId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(vaccinationSchedules)
    .where(eq(vaccinationSchedules.flockId, flockId))
    .orderBy(asc(vaccinationSchedules.scheduledDate));
}

export async function getFlockHealthRecords(flockId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(healthRecords)
    .where(eq(healthRecords.flockId, flockId))
    .orderBy(desc(healthRecords.recordDate));
}

// ============================================================================
// FEED MANUFACTURING
// ============================================================================

export async function listFeedFormulations(filters?: {
  feedRange?: 'premium' | 'value' | 'econo';
  feedStage?: 'starter' | 'grower' | 'finisher';
  isActive?: number;
}) {
  const db = await getDb();
  if (!db) return [];
  const conditions: ReturnType<typeof eq>[] = [];
  if (filters?.feedRange) conditions.push(eq(feedFormulations.feedRange, filters.feedRange));
  if (filters?.feedStage) conditions.push(eq(feedFormulations.feedStage, filters.feedStage));
  if (filters?.isActive !== undefined) conditions.push(eq(feedFormulations.isActive, filters.isActive));
  const query = db.select().from(feedFormulations).orderBy(desc(feedFormulations.createdAt));
  if (conditions.length > 0) {
    return await query.where(and(...conditions));
  }
  return await query;
}

export async function getFeedFormulationById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(feedFormulations).where(eq(feedFormulations.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listFeedBatches(limit = 50) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(feedBatches).orderBy(desc(feedBatches.productionDate)).limit(limit);
}

export async function getFeedBatchById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(feedBatches).where(eq(feedBatches.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listRawMaterials() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(rawMaterials).where(eq(rawMaterials.isActive, true)).orderBy(asc(rawMaterials.name));
}

export async function getRawMaterialById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(rawMaterials).where(eq(rawMaterials.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============================================================================
// CUSTOMER MANAGEMENT
// ============================================================================

export async function listCustomers(filters?: { segment?: string; isActive?: boolean }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(customers).$dynamic();

  if (filters?.segment) {
    query = query.where(eq(customers.segment, filters.segment as any));
  }
  if (filters?.isActive !== undefined) {
    query = query.where(eq(customers.isActive, filters.isActive));
  }

  return await query.orderBy(asc(customers.name));
}

export async function getCustomerById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createCustomer(data: typeof customers.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(customers).values(data);
  return result;
}

export async function getCustomerAddresses(customerId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(customerAddresses).where(eq(customerAddresses.customerId, customerId));
}

// ============================================================================
// SALES & INVOICING
// ============================================================================

export async function listInvoices(filters?: { customerId?: number; status?: string }) {
  const db = await getDb();
  if (!db) return [];

  let query = db
    .select({
      ...invoices,
      customerName: customers.name,
    })
    .from(invoices)
    .leftJoin(customers, eq(invoices.customerId, customers.id))
    .$dynamic();

  if (filters?.customerId) {
    query = query.where(eq(invoices.customerId, filters.customerId));
  }
  if (filters?.status) {
    query = query.where(eq(invoices.status, filters.status as any));
  }

  return await query.orderBy(desc(invoices.invoiceDate));
}

export async function getInvoiceById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select({
      ...invoices,
      customerName: customers.name,
    })
    .from(invoices)
    .leftJoin(customers, eq(invoices.customerId, customers.id))
    .where(eq(invoices.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getInvoiceItems(invoiceId: number) {
  const db = await getDb();
  if (!db) return [];

  const legacyItems = await db
    .select()
    .from(invoiceItems)
    .where(eq(invoiceItems.invoiceId, invoiceId));

  const lineItems = await db
    .select()
    .from(invoiceLineItems)
    .where(eq(invoiceLineItems.invoiceId, invoiceId));

  if (legacyItems.length > 0) {
    return legacyItems.map((item) => ({
      ...item,
      discountPercent: 0,
      discountAmount: 0,
    }));
  }

  if (lineItems.length > 0) {
    return lineItems.map((item) => {
      const pricePerUnit = parseFloat(item.pricePerUnit?.toString() || '0');
      const quantity = parseFloat(item.quantity?.toString() || '0');
      const discountPct = parseFloat(item.discount?.toString() || '0');
      const vatPct = parseFloat(item.vatPercentage?.toString() || '15');

      const subtotal = quantity * pricePerUnit;
      const discountAmount = subtotal * (discountPct / 100);

      const subtotalExcl = subtotal - discountAmount;
      const taxAmt = subtotalExcl * (vatPct / 100);
      const total = subtotalExcl + taxAmt;

      return {
        id: item.id,
        invoiceId: item.invoiceId,
        description: item.description,

        // ✅ IMPORTANT FIX
        quantity: quantity,

        unit: 'unit',
        unitPrice: Math.round(pricePerUnit * 100),
        subtotal: Math.round(subtotalExcl * 100),
        taxRate: vatPct,
        taxAmount: Math.round(taxAmt * 100),
        totalAmount: Math.round(total * 100),

        discountPercent: discountPct,
        discountAmount: Math.round(discountAmount * 100),

        createdAt: item.createdAt,
      };
    });
  }

  // ✅ MISSING IN YOUR FILE
  return [];
}

export async function createInvoiceLineItem(data: {
  invoiceId: number;
  description: string;
  quantity: number;
  pricePerUnit: number;
  discountPercent?: number;
  vatPercentage?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');

  const discount = data.discountPercent ?? 0;
  const vatPct = data.vatPercentage ?? 15;
  const subtotal = data.quantity * data.pricePerUnit;
  const discountAmount = subtotal * (discount / 100);
  const amount = (subtotal - discountAmount) * (1 + vatPct / 100);

  await db.insert(invoiceLineItems).values({
    invoiceId: data.invoiceId,
    description: data.description,
    quantity: data.quantity.toString(),
    pricePerUnit: data.pricePerUnit.toString(),
    discount: discount.toString(),
    discountAmount: discountAmount.toFixed(2),
    vatPercentage: vatPct.toString(),
    amount: amount.toFixed(2),
  });
}

export async function insertInvoiceItems(items: {
  invoiceId: number;
  description: string;
  quantity: number;
  unit?: string;
  unitPrice: number;
  taxRate?: number;
}[]) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  if (!items || items.length === 0) return;

  await db.insert(invoiceLineItems).values(
    items.map((item) => {
      const quantity = Number(item.quantity || 0);
      const pricePerUnit = Number(item.unitPrice || 0);
      const vatPercentage = Number(item.taxRate ?? 15);
      const subtotal = quantity * pricePerUnit;
      const taxAmount = subtotal * (vatPercentage / 100);
      const totalAmount = subtotal + taxAmount;
      return {
        invoiceId: item.invoiceId,
        description: item.description,
        quantity: quantity.toString(),
        pricePerUnit: pricePerUnit.toString(),
        discount: '0',
        discountAmount: '0',
        vatPercentage: vatPercentage.toString(),
        amount: totalAmount.toFixed(2),
      };
    })
  );
}

export async function listPayments(customerId?: number) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(payments).$dynamic();

  if (customerId) {
    query = query.where(eq(payments.customerId, customerId));
  }

  return await query.orderBy(desc(payments.paymentDate));
}

// ============================================================================
// PROCUREMENT & SUPPLIER MANAGEMENT
// ============================================================================

export async function listSuppliers(filters?: { category?: string; isActive?: boolean }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(suppliers).$dynamic();

  if (filters?.category) {
    query = query.where(eq(suppliers.category, filters.category));
  }
  if (filters?.isActive !== undefined) {
    query = query.where(eq(suppliers.isActive, filters.isActive));
  }

  return await query.orderBy(asc(suppliers.name));
}

export async function getSupplierById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listItemTemplates(filters?: { category?: string; isActive?: boolean }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(itemTemplates).$dynamic();

  if (filters?.category) {
    query = query.where(eq(itemTemplates.category, filters.category));
  }
  if (filters?.isActive !== undefined) {
    query = query.where(eq(itemTemplates.isActive, filters.isActive));
  }

  return await query.orderBy(asc(itemTemplates.name));
}

export async function getItemTemplateById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(itemTemplates).where(eq(itemTemplates.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listProcurementSchedules(flockId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(procurementSchedules)
    .where(eq(procurementSchedules.flockId, flockId))
    .orderBy(asc(procurementSchedules.scheduledOrderDate));
}

export async function listUpcomingProcurementSchedules(days = 7) {
  const db = await getDb();
  if (!db) return [];

  const today = new Date();
  const futureDate = new Date();
  futureDate.setDate(today.getDate() + days);

  return await db
    .select()
    .from(procurementSchedules)
    .where(
      and(
        gte(procurementSchedules.scheduledOrderDate, today),
        lte(procurementSchedules.scheduledOrderDate, futureDate),
        eq(procurementSchedules.status, "pending")
      )
    )
    .orderBy(asc(procurementSchedules.scheduledOrderDate));
}

// ============================================================================
// FINANCIAL ACCOUNTING
// ============================================================================

export async function listChartOfAccounts(accountType?: string) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(chartOfAccounts).$dynamic();

  if (accountType) {
    query = query.where(eq(chartOfAccounts.accountType, accountType as any));
  }

  return await query.where(eq(chartOfAccounts.isActive, true)).orderBy(asc(chartOfAccounts.accountNumber));
}

export async function getChartOfAccountById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(chartOfAccounts).where(eq(chartOfAccounts.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listGeneralLedgerEntries(filters?: {
  accountId?: number;
  startDate?: Date;
  endDate?: Date;
}) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(generalLedgerEntries).$dynamic();

  if (filters?.accountId) {
    query = query.where(eq(generalLedgerEntries.accountId, filters.accountId));
  }
  if (filters?.startDate) {
    query = query.where(gte(generalLedgerEntries.entryDate, filters.startDate));
  }
  if (filters?.endDate) {
    query = query.where(lte(generalLedgerEntries.entryDate, filters.endDate));
  }

  return await query.orderBy(desc(generalLedgerEntries.entryDate));
}

// ============================================================================
// INVENTORY MANAGEMENT
// ============================================================================

export async function listInventoryItems(category?: string) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(inventoryItems).$dynamic();

  if (category) {
    query = query.where(eq(inventoryItems.category, category as any));
  }

  return await query.where(eq(inventoryItems.isActive, true)).orderBy(asc(inventoryItems.name));
}

export async function getInventoryItemById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(inventoryItems).where(eq(inventoryItems.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listInventoryLocations() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(inventoryLocations).where(eq(inventoryLocations.isActive, true)).orderBy(asc(inventoryLocations.name));
}

// ============================================================================
// DOCUMENT MANAGEMENT
// ============================================================================

export async function listDocuments(filters?: {
  category?: string;
  relatedEntityType?: string;
  relatedEntityId?: number;
}) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(documents).$dynamic();

  if (filters?.category) {
    query = query.where(eq(documents.category, filters.category as any));
  }
  if (filters?.relatedEntityType && filters?.relatedEntityId) {
    query = query.where(
      and(
        eq(documents.relatedEntityType, filters.relatedEntityType),
        eq(documents.relatedEntityId, filters.relatedEntityId)
      )
    );
  }

  return await query.where(eq(documents.status, "active")).orderBy(desc(documents.uploadedAt));
}

export async function getDocumentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(documents).where(eq(documents.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============================================================================
// ANALYTICS & REPORTING HELPERS
// ============================================================================

export async function getActiveFlockCount() {
  const db = await getDb();
  if (!db) return 0;

  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(flocks)
    .where(eq(flocks.status, "active"));

  return result[0]?.count || 0;
}

export async function getTotalCustomerCount() {
  const db = await getDb();
  if (!db) return 0;

  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(customers)
    .where(eq(customers.isActive, true));

  return result[0]?.count || 0;
}

export async function getMonthlyRevenue(year: number, month: number) {
  const db = await getDb();
  if (!db) return 0;

  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0, 23, 59, 59);

  const result = await db
    .select({ total: sql<number>`sum(${invoices.totalAmount})` })
    .from(invoices)
    .where(
      and(
        gte(invoices.invoiceDate, startDate),
        lte(invoices.invoiceDate, endDate),
        or(eq(invoices.status, "paid"), eq(invoices.status, "partial"))
      )
    );

  return result[0]?.total || 0;
}


// ============================================================================
// ADDITIONAL FLOCK MANAGEMENT FUNCTIONS
// ============================================================================

export async function createHealthRecord(data: typeof healthRecords.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(healthRecords).values(data);
  return result;
}

export async function updateHealthRecord(id: number, data: Partial<typeof healthRecords.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.update(healthRecords).set(data).where(eq(healthRecords.id, id));
  return result;
}

export async function createVaccinationSchedule(data: typeof vaccinationSchedules.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(vaccinationSchedules).values(data);
  return result;
}

export async function updateVaccinationSchedule(id: number, data: Partial<typeof vaccinationSchedules.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(vaccinationSchedules).set(data).where(eq(vaccinationSchedules.id, id));
  return true;
}

export async function getMortalityRecords(flockId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(mortalityRecords)
    .where(eq(mortalityRecords.flockId, flockId))
    .orderBy(asc(mortalityRecords.recordDate));
}

// Advanced Growth Metrics Calculation
export async function getAdvancedGrowthMetrics(flockId: number) {
  const db = await getDb();
  if (!db) return null;

  const flock = await getFlockById(flockId);
  if (!flock) return null;

  const dailyRecords = await getFlockDailyRecords(flockId);
  if (!dailyRecords || dailyRecords.length === 0) return null;

  // Filter records with weight data and sort by day
  const weightRecords = dailyRecords
    .filter(r => r.averageWeight && parseFloat(r.averageWeight.toString()) > 0)
    .sort((a, b) => a.dayNumber - b.dayNumber);

  if (weightRecords.length === 0) return null;

  // Calculate Daily Weight Gain (ADG)
  const adgData = [];
  for (let i = 1; i < weightRecords.length; i++) {
    const prevWeight = parseFloat(weightRecords[i - 1].averageWeight!.toString());
    const currWeight = parseFloat(weightRecords[i].averageWeight!.toString());
    const dayDiff = weightRecords[i].dayNumber - weightRecords[i - 1].dayNumber;
    const dailyGain = dayDiff > 0 ? ((currWeight - prevWeight) * 1000) / dayDiff : 0; // Convert to grams
    adgData.push({
      day: weightRecords[i].dayNumber,
      dailyGain: parseFloat(dailyGain.toFixed(2)),
      weight: currWeight
    });
  }

  const avgDailyGain = adgData.length > 0
    ? adgData.reduce((sum, d) => sum + d.dailyGain, 0) / adgData.length
    : 0;

  // Calculate Uniformity Index (Coefficient of Variation from weight samples)
  let uniformityIndex = null;
  const latestRecord = weightRecords[weightRecords.length - 1];
  if (latestRecord.weightSamples) {
    const samples = latestRecord.weightSamples
      .split(',')
      .map(w => parseFloat(w.trim()))
      .filter(w => !isNaN(w) && w > 0);
    
    if (samples.length >= 3) {
      const mean = samples.reduce((a, b) => a + b, 0) / samples.length;
      const variance = samples.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / samples.length;
      const stdDev = Math.sqrt(variance);
      const cv = (stdDev / mean) * 100;
      uniformityIndex = parseFloat((100 - cv).toFixed(2)); // Higher is better
    }
  }

  // Calculate Projected Final Weight
  const latestWeight = parseFloat(latestRecord.averageWeight!.toString());
  const currentDay = latestRecord.dayNumber;
  const targetDay = flock.growingPeriod || 42;
  const daysRemaining = targetDay - currentDay;
  const projectedFinalWeight = daysRemaining > 0
    ? latestWeight + (avgDailyGain / 1000) * daysRemaining
    : latestWeight;

  // Calculate European Production Index (EPI)
  // EPI = (Livability × Live Weight in kg × 100) / (Age in days × FCR)
  const totalMortality = dailyRecords.reduce((sum, r) => sum + (r.mortality || 0), 0);
  const livability = ((flock.initialCount - totalMortality) / flock.initialCount) * 100;
  const totalFeedConsumed = dailyRecords.reduce((sum, r) => 
    sum + (r.feedConsumed ? parseFloat(r.feedConsumed.toString()) : 0), 0
  );
  const currentCount = flock.initialCount - totalMortality;
  const totalWeight = currentCount * latestWeight;
  const fcr = totalWeight > 0 ? totalFeedConsumed / totalWeight : 0;
  const epi = fcr > 0 && currentDay > 0
    ? (livability * latestWeight * 100) / (currentDay * fcr)
    : 0;

  return {
    avgDailyGain: parseFloat(avgDailyGain.toFixed(2)),
    adgData,
    uniformityIndex,
    projectedFinalWeight: parseFloat(projectedFinalWeight.toFixed(3)),
    epi: parseFloat(epi.toFixed(2)),
    livability: parseFloat(livability.toFixed(2)),
    currentDay,
    latestWeight
  };
}

// Feed Efficiency Metrics Calculation
export async function getFeedEfficiencyMetrics(flockId: number) {
  const db = await getDb();
  if (!db) return null;

  const flock = await getFlockById(flockId);
  if (!flock) return null;

  const dailyRecords = await getFlockDailyRecords(flockId);
  if (!dailyRecords || dailyRecords.length === 0) return null;

  const totalMortality = dailyRecords.reduce((sum, r) => sum + (r.mortality || 0), 0);
  const currentCount = flock.initialCount - totalMortality;

  // Calculate daily feed intake per bird
  const feedIntakeData = dailyRecords
    .filter(r => r.feedConsumed && parseFloat(r.feedConsumed.toString()) > 0)
    .map(r => {
      const birdCount = flock.initialCount - dailyRecords
        .filter(dr => dr.dayNumber <= r.dayNumber)
        .reduce((sum, dr) => sum + (dr.mortality || 0), 0);
      const feedPerBird = birdCount > 0
        ? (parseFloat(r.feedConsumed!.toString()) / birdCount) * 1000 // Convert to grams
        : 0;
      return {
        day: r.dayNumber,
        feedPerBird: parseFloat(feedPerBird.toFixed(2)),
        feedType: r.feedType || 'unknown'
      };
    });

  const avgFeedPerBird = feedIntakeData.length > 0
    ? feedIntakeData.reduce((sum, d) => sum + d.feedPerBird, 0) / feedIntakeData.length
    : 0;

  // Phase order for transition-weight lookups
  const phaseOrder = ['starter', 'grower', 'finisher'];

  // Calculate feed type performance
  // Transition-day rule:
  //   - Phase START weight = weight recorded on the first day of THIS phase (transition day
  //     from the previous phase), OR the last non-zero weight before the phase if none exists.
  //   - Phase END weight   = weight recorded on the first day of the NEXT phase (transition
  //     day into the following phase), OR the last non-zero weight within this phase if there
  //     is no next phase / no weight on the next phase's first day.
  //
  // This ensures the same transition-day weight (e.g. Day 19 when switching starter→grower)
  // is used as both the end weight of the preceding phase and the start weight of the next.
  const feedTypePerformance = phaseOrder.map((type, phaseIdx) => {
    const typeRecords = dailyRecords.filter(r => r.feedType === type);
    if (typeRecords.length === 0) return null;

    const totalFeed = typeRecords.reduce((sum, r) =>
      sum + (r.feedConsumed ? parseFloat(r.feedConsumed.toString()) : 0), 0
    );
    const startDay = Math.min(...typeRecords.map(r => r.dayNumber));
    const endDay   = Math.max(...typeRecords.map(r => r.dayNumber));

    // START weight: first non-zero weight on or before startDay
    const startWeightRecord = dailyRecords
      .filter(r => r.dayNumber <= startDay && r.averageWeight && parseFloat(r.averageWeight.toString()) > 0)
      .sort((a, b) => b.dayNumber - a.dayNumber)[0];

    // END weight: use the first day of the NEXT phase as the transition boundary.
    // If the next phase exists and has a weight on its first day, use that.
    // Otherwise fall back to the last non-zero weight within this phase.
    const nextPhase = phaseOrder[phaseIdx + 1];
    const nextPhaseRecords = nextPhase ? dailyRecords.filter(r => r.feedType === nextPhase) : [];
    const nextPhaseStartDay = nextPhaseRecords.length > 0
      ? Math.min(...nextPhaseRecords.map(r => r.dayNumber))
      : null;
    const nextPhaseStartWeight = nextPhaseStartDay !== null
      ? dailyRecords
          .filter(r => r.dayNumber === nextPhaseStartDay && r.averageWeight && parseFloat(r.averageWeight.toString()) > 0)
          .sort((a, b) => b.dayNumber - a.dayNumber)[0]
      : null;

    // Fall back to last non-zero weight within this phase if no next-phase transition weight
    const endWeightRecord = nextPhaseStartWeight
      ?? dailyRecords
          .filter(r => r.dayNumber <= endDay && r.averageWeight && parseFloat(r.averageWeight.toString()) > 0)
          .sort((a, b) => b.dayNumber - a.dayNumber)[0];

    const startWeightVal = startWeightRecord ? parseFloat(startWeightRecord.averageWeight!.toString()) : 0;
    const endWeightVal   = endWeightRecord   ? parseFloat(endWeightRecord.averageWeight!.toString())   : 0;
    const weightGain = startWeightVal > 0 && endWeightVal > 0
      ? endWeightVal - startWeightVal
      : 0;

    const phaseFCR = weightGain > 0 && currentCount > 0
      ? totalFeed / (currentCount * weightGain)
      : 0;

    return {
      feedType: type,
      totalFeed: parseFloat(totalFeed.toFixed(2)),
      days: endDay - startDay + 1,
      weightGain: parseFloat((weightGain * 1000).toFixed(2)), // Convert to grams
      fcr: parseFloat(phaseFCR.toFixed(3))
    };
  }).filter(Boolean);

  // Calculate water-to-feed ratio
  const waterFeedRatioData = dailyRecords
    .filter(r => r.waterConsumed && r.feedConsumed && 
      parseFloat(r.waterConsumed.toString()) > 0 && parseFloat(r.feedConsumed.toString()) > 0)
    .map(r => ({
      day: r.dayNumber,
      ratio: parseFloat((parseFloat(r.waterConsumed!.toString()) / parseFloat(r.feedConsumed!.toString())).toFixed(2))
    }));

  const avgWaterFeedRatio = waterFeedRatioData.length > 0
    ? waterFeedRatioData.reduce((sum, d) => sum + d.ratio, 0) / waterFeedRatioData.length
    : 0;

  return {
    avgFeedPerBird: parseFloat(avgFeedPerBird.toFixed(2)),
    feedIntakeData,
    feedTypePerformance,
    avgWaterFeedRatio: parseFloat(avgWaterFeedRatio.toFixed(2)),
    waterFeedRatioData
  };
}

export async function getFlockPerformanceMetrics(flockId: number) {
  const db = await getDb();
  if (!db) return null;

  const flock = await getFlockById(flockId);
  if (!flock) return null;

  const dailyRecords = await getFlockDailyRecords(flockId);
  
  // Calculate totals
  const totalFeedConsumed = dailyRecords.reduce((sum, record) => 
    sum + (record.feedConsumed ? parseFloat(record.feedConsumed.toString()) : 0), 0
  );
  
  const totalMortality = dailyRecords.reduce((sum, record) => 
    sum + (record.mortality || 0), 0
  );

  // Get latest weight sample (find the most recent record with a non-zero weight)
  let averageWeight = 0;
  for (let i = 0; i < dailyRecords.length; i++) {
    const record = dailyRecords[i];
    if (record.averageWeight && parseFloat(record.averageWeight.toString()) > 0) {
      averageWeight = parseFloat(record.averageWeight.toString());
    }
  }

  // Calculate current count as initial count minus cumulative mortality
  const calculatedCurrentCount = flock.initialCount - totalMortality;

  // Calculate FCR (Feed Conversion Ratio) using calculated current count
  const totalWeight = calculatedCurrentCount * averageWeight;
  const fcr = totalWeight > 0 ? totalFeedConsumed / totalWeight : 0;

  // Calculate mortality rate
  const mortalityRate = flock.initialCount > 0 
    ? (totalMortality / flock.initialCount) * 100 
    : 0;

  // Calculate age in days (placement day = Day 0)
  // Use UTC dates to ensure consistent calculation regardless of server timezone
  const placementDate = new Date(flock.placementDate);
  const today = new Date();
  // Get UTC date components only (year, month, day) to avoid timezone issues
  const placementUTC = Date.UTC(placementDate.getUTCFullYear(), placementDate.getUTCMonth(), placementDate.getUTCDate());
  const todayUTC = Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate());
  const ageInDays = Math.floor((todayUTC - placementUTC) / (1000 * 60 * 60 * 24));

  const targetWeight = flock.targetSlaughterWeight ? parseFloat(flock.targetSlaughterWeight) : 0;
  const growingPeriod = flock.growingPeriod || 42;

  return {
    flockId: flock.id,
    flockNumber: flock.flockNumber,
    ageInDays,
    currentCount: calculatedCurrentCount,
    initialCount: flock.initialCount,
    totalMortality,
    mortalityRate: parseFloat(mortalityRate.toFixed(2)),
    totalFeedConsumed: parseFloat(totalFeedConsumed.toFixed(2)),
    averageWeight: parseFloat(averageWeight.toFixed(3)),
    fcr: parseFloat(fcr.toFixed(2)),
    targetWeight,
    growingPeriod,
    daysRemaining: growingPeriod - ageInDays,
  };
}


// ============================================================================
// Breed-Specific Target Growth Curve Functions
// ============================================================================

type BreedType = 'ross_308' | 'cobb_500' | 'arbor_acres';

/**
 * Breed-specific growth curves based on official performance objectives (2022)
 * All weights in kg
 */
const BREED_GROWTH_CURVES: Record<BreedType, Record<number, number>> = {
  ross_308: {
    0: 0.042, 7: 0.170, 14: 0.465, 21: 0.925, 28: 1.505, 35: 2.180, 42: 2.950, 49: 3.790,
  },
  cobb_500: {
    0: 0.042, 7: 0.175, 14: 0.480, 21: 0.950, 28: 1.540, 35: 2.215, 42: 2.970, 49: 3.800,
  },
  arbor_acres: {
    0: 0.042, 7: 0.168, 14: 0.458, 21: 0.910, 28: 1.480, 35: 2.145, 42: 2.900, 49: 3.720,
  },
};

/**
 * Get target weight for a specific breed and day
 * Uses linear interpolation for days between defined points
 * Uses linear extrapolation for days beyond 49
 */
export function getTargetWeight(dayNumber: number, breed: BreedType = 'ross_308'): number {
  const growthCurve = BREED_GROWTH_CURVES[breed];
  
  // If exact day exists, return it
  if (growthCurve[dayNumber] !== undefined) {
    return growthCurve[dayNumber]!;
  }
  
  // Get sorted day keys
  const days = Object.keys(growthCurve).map(Number).sort((a, b) => a - b);
  
  // For days before first defined point
  if (dayNumber < days[0]!) {
    return growthCurve[days[0]!]!;
  }
  
  // For days beyond last defined point, use linear extrapolation
  if (dayNumber > days[days.length - 1]!) {
    const lastDay = days[days.length - 1]!;
    const secondLastDay = days[days.length - 2]!;
    const dailyGain = (growthCurve[lastDay]! - growthCurve[secondLastDay]!) / (lastDay - secondLastDay);
    return growthCurve[lastDay]! + (dayNumber - lastDay) * dailyGain;
  }
  
  // For days between defined points, use linear interpolation
  for (let i = 0; i < days.length - 1; i++) {
    const lowerDay = days[i]!;
    const upperDay = days[i + 1]!;
    
    if (dayNumber >= lowerDay && dayNumber <= upperDay) {
      const fraction = (dayNumber - lowerDay) / (upperDay - lowerDay);
      return growthCurve[lowerDay]! + (growthCurve[upperDay]! - growthCurve[lowerDay]!) * fraction;
    }
  }
  
  // Fallback
  return 0.042;
}

/**
 * Legacy function for backward compatibility - defaults to Ross 308
 * @deprecated Use getTargetWeight(dayNumber, breed) instead
 */
function getTargetWeightLegacy(dayNumber: number): number {
  return getTargetWeight(dayNumber, 'ross_308');
}

/**
 * Get target growth curve data for charting (breed-specific)
 * Returns array of {day, targetWeight} for the specified day range
 */
export function getTargetGrowthCurve(startDay: number = 0, endDay: number = 42, breed: BreedType = 'ross_308'): Array<{ day: number; targetWeight: number }> {
  const curve: Array<{ day: number; targetWeight: number }> = [];
  
  for (let day = startDay; day <= endDay; day++) {
    curve.push({
      day,
      targetWeight: getTargetWeight(day, breed),
    });
  }
  
  return curve;
}

/**
 * Calculate performance deviation from target (breed-specific)
 * Returns percentage deviation (positive = ahead of target, negative = behind target)
 */
export function calculatePerformanceDeviation(actualWeight: number, dayNumber: number, breed: BreedType = 'ross_308'): number {
  const targetWeight = getTargetWeight(dayNumber, breed);
  if (targetWeight === 0) return 0;
  
  const deviation = ((actualWeight - targetWeight) / targetWeight) * 100;
  return Math.round(deviation * 10) / 10; // Round to 1 decimal place
}

/**
 * Get performance status based on deviation from target
 * Returns: 'ahead' | 'on-track' | 'behind' | 'critical'
 */
export function getPerformanceStatus(deviation: number): 'ahead' | 'on-track' | 'behind' | 'critical' {
  if (deviation >= 5) return 'ahead';           // 5% or more ahead
  if (deviation >= -5) return 'on-track';       // Within ±5%
  if (deviation > -10) return 'behind';         // 5-10% behind (not including -10%)
  return 'critical';                             // -10% or more behind
}


/**
 * Validate if target weight is realistic for given breed and growing period
 * Returns { isRealistic: boolean, expectedWeight: number, message: string }
 */
export function validateTargetWeight(
  breed: "ross_308" | "cobb_500" | "arbor_acres",
  growingPeriod: number,
  targetWeight: number
): { isRealistic: boolean; expectedWeight: number; message: string } {
  const expectedWeight = getTargetWeight(growingPeriod, breed);
  const deviation = ((targetWeight - expectedWeight) / expectedWeight) * 100;
  
  // Allow ±15% deviation from expected weight
  const isRealistic = Math.abs(deviation) <= 15;
  
  let message = "";
  if (!isRealistic) {
    if (deviation > 15) {
      message = `Target weight (${targetWeight.toFixed(2)}kg) is ${deviation.toFixed(1)}% higher than expected ${expectedWeight.toFixed(2)}kg for ${breed.replace("_", " ")} at day ${growingPeriod}. This may be unrealistic.`;
    } else {
      message = `Target weight (${targetWeight.toFixed(2)}kg) is ${Math.abs(deviation).toFixed(1)}% lower than expected ${expectedWeight.toFixed(2)}kg for ${breed.replace("_", " ")} at day ${growingPeriod}. This may indicate poor performance.`;
    }
  } else {
    message = `Target weight is realistic for ${breed.replace("_", " ")} at day ${growingPeriod} (expected: ${expectedWeight.toFixed(2)}kg)`;
  }
  
  return { isRealistic, expectedWeight, message };
}


// ============================================================================
// REMINDER MANAGEMENT
// ============================================================================

export async function listReminders(filters?: {
  flockId?: number;
  houseId?: number;
  status?: string;
  statusIn?: string[];
  priority?: string;
  startDate?: Date;
  endDate?: Date;
  completedStartDate?: Date;
  completedEndDate?: Date;
}) {
  const db = await getDb();
  if (!db) return [];

  // Build conditions array to combine with and()
  const conditions: any[] = [];

  if (filters?.flockId !== undefined) {
    // When filtering by flockId, only return reminders for that specific flock
    // This excludes reminders with null flockId (orphaned test data)
    conditions.push(eq(reminders.flockId, filters.flockId));
  }
  if (filters?.houseId) {
    conditions.push(eq(reminders.houseId, filters.houseId));
  }
  if (filters?.status) {
    conditions.push(eq(reminders.status, filters.status as any));
  }
  if (filters?.statusIn && filters.statusIn.length > 0) {
    conditions.push(inArray(reminders.status, filters.statusIn as any));
  }
  if (filters?.priority) {
    conditions.push(eq(reminders.priority, filters.priority as any));
  }
  if (filters?.startDate) {
    conditions.push(gte(reminders.dueDate, filters.startDate));
  }
  if (filters?.endDate) {
    conditions.push(lte(reminders.dueDate, filters.endDate));
  }
  if (filters?.completedStartDate) {
    conditions.push(gte(reminders.completedAt, filters.completedStartDate));
  }
  if (filters?.completedEndDate) {
    conditions.push(lte(reminders.completedAt, filters.completedEndDate));
  }

  // Apply all conditions with and()
  let query = db.select().from(reminders).$dynamic();
  if (conditions.length > 0) {
    query = query.where(and(...conditions));
  }

  // Order by completedAt desc if filtering by completion date, otherwise by dueDate asc
  if (filters?.completedStartDate || filters?.completedEndDate) {
    return await query.orderBy(desc(reminders.completedAt));
  }
  return await query.orderBy(asc(reminders.dueDate));
}

export async function getUpcomingReminders(days: number = 7) {
  const db = await getDb();
  if (!db) return [];

  // Use UTC dates to ensure consistent filtering regardless of server timezone
  const now = new Date();
  const todayStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), 0, 0, 0, 0));
  const futureDate = new Date(todayStart);
  futureDate.setUTCDate(futureDate.getUTCDate() + days);

  const results = await db
    .select({
      id: reminders.id,
      flockId: reminders.flockId,
      houseId: reminders.houseId,
      reminderType: reminders.reminderType,
      title: reminders.title,
      description: reminders.description,
      dueDate: reminders.dueDate,
      priority: reminders.priority,
      status: reminders.status,
      completedAt: reminders.completedAt,
      completedBy: reminders.completedBy,
      templateId: reminders.templateId,
      actionNotes: reminders.actionNotes,
      createdAt: reminders.createdAt,
      updatedAt: reminders.updatedAt,
      houseName: houses.name,
    })
    .from(reminders)
    .leftJoin(houses, eq(reminders.houseId, houses.id))
    .where(
      and(
        gte(reminders.dueDate, todayStart),
        lte(reminders.dueDate, futureDate),
        eq(reminders.status, "pending")
      )
    )
    .orderBy(asc(reminders.dueDate));

  return results;
}

export async function getTodayReminders() {
  const db = await getDb();
  if (!db) return [];

  // Use UTC dates to ensure consistent filtering regardless of server timezone
  const now = new Date();
  const todayStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), 0, 0, 0, 0));
  const todayEnd = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), 23, 59, 59, 999));

  const results = await db
    .select({
      id: reminders.id,
      flockId: reminders.flockId,
      houseId: reminders.houseId,
      reminderType: reminders.reminderType,
      title: reminders.title,
      description: reminders.description,
      dueDate: reminders.dueDate,
      priority: reminders.priority,
      status: reminders.status,
      completedAt: reminders.completedAt,
      completedBy: reminders.completedBy,
      templateId: reminders.templateId,
      actionNotes: reminders.actionNotes,
      createdAt: reminders.createdAt,
      updatedAt: reminders.updatedAt,
      houseName: houses.name,
    })
    .from(reminders)
    .leftJoin(houses, eq(reminders.houseId, houses.id))
    .where(
      and(
        gte(reminders.dueDate, todayStart),
        lte(reminders.dueDate, todayEnd),
        eq(reminders.status, "pending")
      )
    )
    .orderBy(asc(reminders.dueDate));

  return results;
}

export async function listAllRemindersWithFlockInfo() {
  const db = await getDb();
  if (!db) return [];

  const results = await db
    .select({
      id: reminders.id,
      flockId: reminders.flockId,
      houseId: reminders.houseId,
      reminderType: reminders.reminderType,
      title: reminders.title,
      description: reminders.description,
      dueDate: reminders.dueDate,
      priority: reminders.priority,
      status: reminders.status,
      completedAt: reminders.completedAt,
      completedBy: reminders.completedBy,
      templateId: reminders.templateId,
      actionNotes: reminders.actionNotes,
      createdAt: reminders.createdAt,
      updatedAt: reminders.updatedAt,
      flockNumber: flocks.flockNumber,
      houseName: houses.name,
    })
    .from(reminders)
    .leftJoin(flocks, eq(reminders.flockId, flocks.id))
    .leftJoin(houses, eq(reminders.houseId, houses.id))
    .orderBy(asc(reminders.dueDate));

  return results;
}

export async function createReminder(data: typeof reminders.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(reminders).values(data);
  return { insertId: (result as any)[0]?.insertId || (result as any).insertId };
}

export async function updateReminderStatus(
  id: number,
  status: "pending" | "completed" | "dismissed",
  completedBy?: number,
  actionNotes?: string,
  completedAt?: Date
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: any = { status };
  if (completedBy) {
    updateData.completedBy = completedBy;
    // Use provided completedAt timestamp or generate current time
    const timestamp = completedAt || new Date();
    updateData.completedAt = timestamp.toISOString().slice(0, 19).replace('T', ' ');
  }
  if (actionNotes) {
    updateData.actionNotes = actionNotes;
  }

  try {
    console.log('Updating reminder with data:', { id, updateData, completedBy, completedAt });
    
    // Verify user exists if completedBy is provided
    if (completedBy && db.query) {
      try {
        const user = await db.query.users.findFirst({
          where: eq(users.id, completedBy),
        });
        if (!user) {
          console.error('User not found for completedBy:', { completedBy });
          throw new Error(`User with ID ${completedBy} not found`);
        }
        console.log('User verified for completedBy:', { userId: completedBy, userName: user.name });
      } catch (queryError) {
        console.warn('Could not verify user existence:', queryError);
        // Continue anyway - the foreign key constraint will catch it if user doesn't exist
      }
    }
    
    // Verify reminder exists if db.query is available
    if (db.query) {
      try {
        const reminder = await db.query.reminders.findFirst({
          where: eq(reminders.id, id),
        });
        if (!reminder) {
          throw new Error(`Reminder with ID ${id} not found`);
        }
        console.log('Reminder found:', { id, currentStatus: reminder.status });
      } catch (queryError) {
        console.warn('Could not verify reminder existence:', queryError);
        // Continue anyway - the update will fail if reminder doesn't exist
      }
    }
    
    await db.update(reminders).set(updateData).where(eq(reminders.id, id));
    console.log('Reminder updated successfully:', { id, newStatus: updateData.status });
    return { success: true };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    const errorCode = (error as any)?.code || 'UNKNOWN';
    const errorSql = (error as any)?.sql || 'N/A';
    console.error('Error updating reminder:', { 
      id, 
      updateData, 
      error: errorMsg, 
      errorCode,
      errorSql,
      fullError: error 
    });
    throw new Error(`Failed to update reminder: ${errorMsg}`);
  }
}

export async function deleteReminder(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(reminders).where(eq(reminders.id, id));
  return { success: true };
}

/**
 * Generate automatic reminders for a flock based on placement date and configuration
 */
export async function generateFlockReminders(flockId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const flock = await getFlockById(flockId);
  if (!flock) throw new Error("Flock not found");

  const house = await getHouseById(flock.houseId);
  if (!house) throw new Error("House not found");

  const placementDate = new Date(flock.placementDate);
  const remindersToCreate: Array<typeof reminders.$inferInsert> = [];

  // House Preparation Reminders (before placement)
  const cleaningDate = new Date(placementDate);
  cleaningDate.setDate(cleaningDate.getDate() - 7);
  remindersToCreate.push({
    flockId,
    houseId: flock.houseId,
    reminderType: "house_preparation",
    title: `House Cleaning - ${house.name}`,
    description: `Clean and wash house ${house.name} in preparation for flock ${flock.flockNumber}`,
    dueDate: cleaningDate,
    priority: "high",
  });

  const disinfectionDate = new Date(placementDate);
  disinfectionDate.setDate(disinfectionDate.getDate() - 3);
  remindersToCreate.push({
    flockId,
    houseId: flock.houseId,
    reminderType: "house_preparation",
    title: `Disinfection - ${house.name}`,
    description: `Disinfect house ${house.name} for flock ${flock.flockNumber}`,
    dueDate: disinfectionDate,
    priority: "high",
  });

  const beddingDate = new Date(placementDate);
  beddingDate.setDate(beddingDate.getDate() - 3);
  remindersToCreate.push({
    flockId,
    houseId: flock.houseId,
    reminderType: "house_preparation",
    title: `Pine Shavings Delivery - ${house.name}`,
    description: `Ensure pine shavings are delivered for house ${house.name}`,
    dueDate: beddingDate,
    priority: "high",
  });

  // Feed Transition Reminders
  if (flock.starterToDay) {
    const starterToGrowerDate = new Date(placementDate);
    starterToGrowerDate.setDate(starterToGrowerDate.getDate() + (flock.starterToDay || 0));
    remindersToCreate.push({
      flockId,
      houseId: flock.houseId,
      reminderType: "feed_transition",
      title: `Feed Transition: Starter → Grower`,
      description: `Change from ${flock.starterFeedType} starter to ${flock.growerFeedType} grower feed for flock ${flock.flockNumber}`,
      dueDate: starterToGrowerDate,
      priority: "high",
    });
  }

  if (flock.growerToDay) {
    const growerToFinisherDate = new Date(placementDate);
    growerToFinisherDate.setDate(growerToFinisherDate.getDate() + (flock.growerToDay || 0));
    remindersToCreate.push({
      flockId,
      houseId: flock.houseId,
      reminderType: "feed_transition",
      title: `Feed Transition: Grower → Finisher`,
      description: `Change from ${flock.growerFeedType} grower to ${flock.finisherFeedType} finisher feed for flock ${flock.flockNumber}`,
      dueDate: growerToFinisherDate,
      priority: "high",
    });
  }

  // Vaccination Reminders (get from vaccination schedule)
  const vaccinations = await getFlockVaccinationSchedule(flockId);
  for (const vacc of vaccinations) {
    if (vacc.status === "scheduled") {
      remindersToCreate.push({
        flockId,
        houseId: flock.houseId,
        reminderType: "vaccination",
        title: `Vaccination: ${vacc.vaccineName}`,
        description: `Administer ${vacc.vaccineName} to flock ${flock.flockNumber}. Dosage: ${vacc.dosage || "As per protocol"}`,
        dueDate: vacc.scheduledDate,
        priority: "urgent",
      });
    }
  }

  // Routine Task Reminders
  const weightSamplingDays = [7, 14, 21, 28, 35, 42];
  for (const day of weightSamplingDays) {
    if (day <= (flock.growingPeriod || 42)) {
      const samplingDate = new Date(placementDate);
      samplingDate.setDate(samplingDate.getDate() + day);
      remindersToCreate.push({
        flockId,
        houseId: flock.houseId,
        reminderType: "routine_task",
        title: `Weight Sampling - Day ${day}`,
        description: `Conduct weight sampling for flock ${flock.flockNumber} (Day ${day})`,
        dueDate: samplingDate,
        priority: "medium",
      });
    }
  }

  // Milestone Reminders
  const slaughterDate = new Date(placementDate);
  slaughterDate.setDate(slaughterDate.getDate() + (flock.growingPeriod || 42));
  remindersToCreate.push({
    flockId,
    houseId: flock.houseId,
    reminderType: "milestone",
    title: `Expected Slaughter Date`,
    description: `Flock ${flock.flockNumber} reaches target age (${flock.growingPeriod || 42} days)`,
    dueDate: slaughterDate,
    priority: "high",
  });

  // Biosecurity Reminders (recurring every 3 days for footbath)
  for (let day = 0; day <= (flock.growingPeriod || 42); day += 3) {
    const footbathDate = new Date(placementDate);
    footbathDate.setDate(footbathDate.getDate() + day);
    remindersToCreate.push({
      flockId,
      houseId: flock.houseId,
      reminderType: "biosecurity",
      title: `Footbath Solution Change`,
      description: `Change footbath solution for house ${house.name}`,
      dueDate: footbathDate,
      priority: "low",
    });
  }

  // Environmental Check Reminders (weekly)
  for (let week = 1; week <= Math.ceil((flock.growingPeriod || 42) / 7); week++) {
    const checkDate = new Date(placementDate);
    checkDate.setDate(checkDate.getDate() + (week * 7));
    remindersToCreate.push({
      flockId,
      houseId: flock.houseId,
      reminderType: "environmental_check",
      title: `Environmental Check - Week ${week}`,
      description: `Check temperature, humidity, and CO2 levels for house ${house.name}`,
      dueDate: checkDate,
      priority: "medium",
    });
  }

  // Insert all reminders
  if (remindersToCreate.length > 0) {
    await db.insert(reminders).values(remindersToCreate);
  }

  return remindersToCreate.length;
}

export async function generateRemindersFromTemplates(flockId: number, templateIds: number[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  if (templateIds.length === 0) return 0;

  const flock = await getFlockById(flockId);
  if (!flock) throw new Error("Flock not found");

  const templates = await db.select().from(reminderTemplates).where(inArray(reminderTemplates.id, templateIds));
  const placementDate = new Date(flock.placementDate);
  const remindersToCreate: Array<typeof reminders.$inferInsert> = [];

  for (const template of templates) {
    // Check if this is a bundle template
    if (template.isBundle && template.bundleConfig) {
      // Generate multiple reminders from bundle configuration
      const bundleConfig = template.bundleConfig as any[];
      for (const category of bundleConfig) {
        if (category.enabled && category.reminders) {
          // Get the reminderType from the category level (e.g., "vaccination", "feed_transition")
          const categoryReminderType = category.category as string;
          
          for (const reminderDef of category.reminders) {
            // Use 'name' field from bundle config (not 'title')
            const reminderTitle = reminderDef.name || reminderDef.title;
            // Use category-level reminderType, fallback to reminderDef.reminderType if exists
            const reminderType = reminderDef.reminderType || categoryReminderType;
            
            // For feed_transition reminders, use flock's actual feed schedule instead of template dayOffset
            let actualDayOffset = reminderDef.dayOffset;
            if (reminderType === "feed_transition") {
              if (reminderTitle.includes("Starter") && reminderTitle.includes("Grower")) {
                actualDayOffset = flock.starterToDay || reminderDef.dayOffset;
              } else if (reminderTitle.includes("Grower") && reminderTitle.includes("Finisher")) {
                actualDayOffset = flock.growerToDay || reminderDef.dayOffset;
              }
            }
            
            const dueDate = new Date(placementDate);
            dueDate.setDate(dueDate.getDate() + actualDayOffset);
            
            remindersToCreate.push({
              flockId,
              houseId: flock.houseId,
              reminderType: reminderType,
              title: reminderTitle,
              description: reminderDef.description || `${reminderTitle} for flock ${flock.flockNumber}`,
              dueDate,
              priority: reminderDef.priority,
              templateId: template.id,
            });
          }
        }
      }
    } else {
      // Single reminder template
      const dueDate = new Date(placementDate);
      dueDate.setDate(dueDate.getDate() + template.dayOffset);

      remindersToCreate.push({
        flockId,
        houseId: flock.houseId,
        reminderType: template.reminderType,
        title: template.name,
        description: template.description || `${template.name} for flock ${flock.flockNumber}`,
        dueDate,
        priority: template.priority,
        templateId: template.id,
      });
    }
  }

  if (remindersToCreate.length > 0) {
    await db.insert(reminders).values(remindersToCreate);
  }

  return remindersToCreate.length;
}

/**
 * Generate reminders from templates, filtering out ones that already exist
 */
export async function generateRemindersFromTemplatesWithFilter(
  flockId: number, 
  templateIds: number[], 
  existingKeys: Set<string>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  if (templateIds.length === 0) return 0;

  const flock = await getFlockById(flockId);
  if (!flock) throw new Error("Flock not found");

  const templates = await db.select().from(reminderTemplates).where(inArray(reminderTemplates.id, templateIds));
  const placementDate = new Date(flock.placementDate);
  const remindersToCreate: Array<typeof reminders.$inferInsert> = [];

  for (const template of templates) {
    if (template.isBundle && template.bundleConfig) {
      const bundleConfig = template.bundleConfig as any[];
      for (const category of bundleConfig) {
        if (category.enabled && category.reminders) {
          const categoryReminderType = category.category as string;
          
          for (const reminderDef of category.reminders) {
            const reminderTitle = reminderDef.name || reminderDef.title;
            const reminderType = reminderDef.reminderType || categoryReminderType;
            
            let actualDayOffset = reminderDef.dayOffset;
            if (reminderType === "feed_transition") {
              if (reminderTitle.includes("Starter") && reminderTitle.includes("Grower")) {
                actualDayOffset = flock.starterToDay || reminderDef.dayOffset;
              } else if (reminderTitle.includes("Grower") && reminderTitle.includes("Finisher")) {
                actualDayOffset = flock.growerToDay || reminderDef.dayOffset;
              }
            }
            
            const dueDate = new Date(placementDate);
            dueDate.setDate(dueDate.getDate() + actualDayOffset);
            
            // Check if this reminder already exists (skip if it does)
            const reminderKey = `${reminderTitle}|${dueDate.toISOString().split('T')[0]}`;
            if (existingKeys.has(reminderKey)) {
              continue; // Skip existing reminders
            }
            
            remindersToCreate.push({
              flockId,
              houseId: flock.houseId,
              reminderType: reminderType,
              title: reminderTitle,
              description: reminderDef.description || `${reminderTitle} for flock ${flock.flockNumber}`,
              dueDate,
              priority: reminderDef.priority,
              templateId: template.id,
            });
          }
        }
      }
    } else {
      const dueDate = new Date(placementDate);
      dueDate.setDate(dueDate.getDate() + template.dayOffset);
      
      // Check if this reminder already exists (skip if it does)
      const reminderKey = `${template.name}|${dueDate.toISOString().split('T')[0]}`;
      if (existingKeys.has(reminderKey)) {
        continue; // Skip existing reminders
      }

      remindersToCreate.push({
        flockId,
        houseId: flock.houseId,
        reminderType: template.reminderType,
        title: template.name,
        description: template.description || `${template.name} for flock ${flock.flockNumber}`,
        dueDate,
        priority: template.priority,
        templateId: template.id,
      });
    }
  }

  if (remindersToCreate.length > 0) {
    await db.insert(reminders).values(remindersToCreate);
  }

  return remindersToCreate.length;
}

// ============================================================================
// HEALTH MANAGEMENT HELPERS
// ============================================================================

export async function listVaccines() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(vaccines);
}

export async function listStressPacks() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(stressPacks);
}

export async function getVaccineById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(vaccines).where(eq(vaccines.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getStressPackById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(stressPacks).where(eq(stressPacks.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createVaccine(data: typeof vaccines.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(vaccines).values(data);
  return { id: Number((result as any).insertId) };
}

export async function updateVaccine(data: { id: number } & Partial<typeof vaccines.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { id, ...updates } = data;
  await db.update(vaccines).set(updates).where(eq(vaccines.id, id));
  return { success: true };
}

export async function deleteVaccine(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(vaccines).where(eq(vaccines.id, id));
  return { success: true };
}

export async function createStressPack(data: typeof stressPacks.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(stressPacks).values(data);
  return { id: Number((result as any).insertId) };
}

export async function updateStressPack(data: { id: number } & Partial<typeof stressPacks.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { id, ...updates } = data;
  await db.update(stressPacks).set(updates).where(eq(stressPacks.id, id));
  return { success: true };
}

export async function deleteStressPack(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(stressPacks).where(eq(stressPacks.id, id));
  return { success: true };
}

export async function listReminderTemplates() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(reminderTemplates).where(eq(reminderTemplates.isActive, true));
}

export async function createReminderTemplate(data: typeof reminderTemplates.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(reminderTemplates).values(data);
  // MySQL returns insertId in the result array
  const insertId = (result as any)[0]?.insertId ?? (result as any).insertId;
  return { id: Number(insertId) };
}

export async function updateReminderTemplate(data: { id: number } & Partial<typeof reminderTemplates.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { id, ...updates } = data;
  await db.update(reminderTemplates).set(updates).where(eq(reminderTemplates.id, id));
  return { success: true };
}

export async function deleteReminderTemplate(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(reminderTemplates).where(eq(reminderTemplates.id, id));
  return { success: true };
}

/**
 * Create a bundle template from multiple existing templates
 * The bundle will contain references to the selected templates and generate all their reminders when applied
 */
export async function createBundleTemplate(name: string, description: string | undefined, templateIds: number[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Get the selected templates to build the bundle config
  const selectedTemplates = await db.select().from(reminderTemplates)
    .where(inArray(reminderTemplates.id, templateIds));

  if (selectedTemplates.length === 0) {
    throw new Error("No valid templates found");
  }

  // Group templates by reminderType to create categories
  const categoriesMap = new Map<string, any[]>();
  for (const template of selectedTemplates) {
    const category = template.reminderType;
    if (!categoriesMap.has(category)) {
      categoriesMap.set(category, []);
    }
    categoriesMap.get(category)!.push({
      name: template.name,
      dayOffset: template.dayOffset,
      priority: template.priority,
      description: template.description,
      sourceTemplateId: template.id,
    });
  }

  // Build bundle config from categories
  const bundleConfig = Array.from(categoriesMap.entries()).map(([category, reminders]) => ({
    category,
    enabled: true,
    reminders,
  }));

  // Create the bundle template
  const result = await db.insert(reminderTemplates).values({
    name,
    description,
    reminderType: "routine_task", // Default type for bundles
    priority: "medium",
    dayOffset: 0,
    isBundle: true,
    bundleConfig,
    isActive: true,
  });

  // MySQL returns insertId in the result array
  const insertId = (result as any)[0]?.insertId ?? (result as any).insertId;
  return { id: Number(insertId), templateCount: selectedTemplates.length };
}

/**
 * Update an existing bundle template
 */
export async function updateBundleTemplate(id: number, name: string, description: string | undefined, bundleConfig: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.update(reminderTemplates)
    .set({
      name,
      description,
      bundleConfig,
    })
    .where(eq(reminderTemplates.id, id));

  return { success: true };
}

/**
 * Copy a template and customize its bundle configuration
 */
export async function copyAndCustomizeTemplate(sourceTemplateId: number, newName: string, customBundleConfig: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Get source template
  const [sourceTemplate] = await db.select().from(reminderTemplates).where(eq(reminderTemplates.id, sourceTemplateId));
  if (!sourceTemplate) throw new Error("Source template not found");

  // Create new template with customized configuration
  const [result] = await db.insert(reminderTemplates).values({
    name: newName,
    description: sourceTemplate.description,
    reminderType: sourceTemplate.reminderType,
    priority: sourceTemplate.priority,
    dayOffset: sourceTemplate.dayOffset,
    isBundle: true,
    bundleConfig: customBundleConfig,
    isActive: true,
  });

  // Return the newly created template
  const [newTemplate] = await db.select().from(reminderTemplates).where(eq(reminderTemplates.name, newName)).orderBy(desc(reminderTemplates.id)).limit(1);
  return newTemplate;
}


export async function updateFeedTransitionReminderDates(
  flockId: number,
  starterToDay?: number,
  growerFromDay?: number,
  growerToDay?: number,
  finisherFromDay?: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const flock = await getFlockById(flockId);
  if (!flock) throw new Error("Flock not found");

  const placementDate = new Date(flock.placementDate);

  // Update Starter → Grower transition reminder
  if (starterToDay !== undefined || growerFromDay !== undefined) {
    const transitionDay = starterToDay !== undefined ? starterToDay : growerFromDay;
    if (transitionDay !== undefined) {
      const newDueDate = new Date(placementDate);
      newDueDate.setDate(newDueDate.getDate() + transitionDay);

      await db
        .update(reminders)
        .set({ dueDate: newDueDate })
        .where(
          and(
            eq(reminders.flockId, flockId),
            eq(reminders.reminderType, "feed_transition"),
            like(reminders.title, "%Starter%Grower%")
          )
        );
    }
  }

  // Update Grower → Finisher transition reminder
  if (growerToDay !== undefined || finisherFromDay !== undefined) {
    const transitionDay = growerToDay !== undefined ? growerToDay : finisherFromDay;
    if (transitionDay !== undefined) {
      const newDueDate = new Date(placementDate);
      newDueDate.setDate(newDueDate.getDate() + transitionDay);

      await db
        .update(reminders)
        .set({ dueDate: newDueDate })
        .where(
          and(
            eq(reminders.flockId, flockId),
            eq(reminders.reminderType, "feed_transition"),
            like(reminders.title, "%Grower%Finisher%")
          )
        );
    }
  }

  return true;
}


/**
 * Automatically activate flocks whose placement date has arrived
 * Called periodically (e.g., daily cron job or on-demand)
 */
export async function autoActivateFlocks() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  
  // Find flocks that should be activated (planned status + placement date <= today)
  const flocksToActivate = await db
    .select()
    .from(flocks)
    .where(
      and(
        eq(flocks.status, "planned"),
        lte(flocks.placementDate, now)
      )
    );

  for (const flock of flocksToActivate) {
    await db
      .update(flocks)
      .set({
        status: "active",
        statusChangedAt: now,
        isManualStatusChange: 0, // automatic
        statusChangeReason: "Automatic activation on placement date",
      })
      .where(eq(flocks.id, flock.id));
  }

  return flocksToActivate.length;
}

/**
 * Manually change flock status with audit trail
 */
export async function manuallyChangeFlockStatus(
  flockId: number,
  newStatus: "planned" | "active" | "completed" | "cancelled",
  userId: number,
  reason: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(flocks)
    .set({
      status: newStatus,
      statusChangedAt: new Date(),
      statusChangedBy: userId,
      statusChangeReason: reason,
      isManualStatusChange: 1, // manual
    })
    .where(eq(flocks.id, flockId));

  return true;
}

/**
 * Get status change history for a flock
 */
export async function getFlockStatusHistory(flockId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const flock = await getFlockById(flockId);
  if (!flock) return [];

  // For now, return the current status change info
  // In future, could create a separate status_history table for full history
  return [
    {
      status: flock.status,
      changedAt: flock.statusChangedAt,
      changedBy: flock.statusChangedBy,
      reason: flock.statusChangeReason,
      isManual: flock.isManualStatusChange === 1,
    },
  ];
}


// ============================================================================
// HEALTH PROTOCOL TEMPLATES
// ============================================================================

/**
 * Create a new health protocol template
 */
export async function createHealthProtocolTemplate(data: typeof healthProtocolTemplates.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(healthProtocolTemplates).values(data);
  return result;
}

/**
 * Get all health protocol templates
 */
export async function getHealthProtocolTemplates() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db
    .select()
    .from(healthProtocolTemplates)
    .where(eq(healthProtocolTemplates.isActive, true))
    .orderBy(desc(healthProtocolTemplates.createdAt));
}

/**
 * Get a health protocol template by ID
 */
export async function getHealthProtocolTemplateById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const results = await db
    .select()
    .from(healthProtocolTemplates)
    .where(eq(healthProtocolTemplates.id, id));
  
  return results[0] || null;
}

/**
 * Update a health protocol template
 */
export async function updateHealthProtocolTemplate(
  id: number,
  data: Partial<typeof healthProtocolTemplates.$inferInsert>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db
    .update(healthProtocolTemplates)
    .set(data)
    .where(eq(healthProtocolTemplates.id, id));
  
  return true;
}

/**
 * Delete a health protocol template (soft delete)
 */
export async function deleteHealthProtocolTemplate(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db
    .update(healthProtocolTemplates)
    .set({ isActive: false })
    .where(eq(healthProtocolTemplates.id, id));
  
  return true;
}


/**
 * Sync flock reminders from a template - preserves completed/dismissed reminders,
 * removes pending reminders, and regenerates only NEW reminders from the updated template
 */
export async function syncFlockRemindersFromTemplate(flockId: number, templateId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Get only completed/dismissed reminders for this flock/template (to avoid duplicates)
  // We only want to preserve these - pending reminders will be regenerated
  const existingReminders = await db.select({ title: reminders.title, dueDate: reminders.dueDate, status: reminders.status })
    .from(reminders)
    .where(and(
      eq(reminders.flockId, flockId),
      eq(reminders.templateId, templateId),
      or(
        eq(reminders.status, "completed"),
        eq(reminders.status, "dismissed")
      )
    ));
  
  // Create a set of existing reminder keys (title + dueDate as date-only) for quick lookup
  const existingKeys = new Set(
    existingReminders.map(r => {
      const dateStr = r.dueDate ? r.dueDate.toISOString().split('T')[0] : '';
      return `${r.title}|${dateStr}`;
    })
  );

  // Delete only pending reminders from this template (preserve completed/dismissed)
  await db.delete(reminders)
    .where(and(
      eq(reminders.flockId, flockId),
      eq(reminders.templateId, templateId),
      eq(reminders.status, "pending")
    ));

  // Generate new reminders but filter out ones that already exist (completed/dismissed)
  const newReminderCount = await generateRemindersFromTemplatesWithFilter(flockId, [templateId], existingKeys);
  
  return { newReminderCount };
}

/**
 * Get all flocks that use a specific template
 */
export async function getFlocksUsingTemplate(templateId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Find flocks that have reminders with this templateId
  const results = await db
    .selectDistinct({ flockId: reminders.flockId })
    .from(reminders)
    .where(eq(reminders.templateId, templateId));

  const flockIds = results.map(r => r.flockId).filter((id): id is number => id !== null);
  if (flockIds.length === 0) return [];

  // Get full flock details
  const flockList = await db
    .select()
    .from(flocks)
    .where(inArray(flocks.id, flockIds));

  return flockList;
}

export async function getFlockActivityLogs(flockId: number) {
  const db = await getDb();
  if (!db) return [];

  const logs = await db
    .select({
      id: userActivityLogs.id,
      userId: userActivityLogs.userId,
      action: userActivityLogs.action,
      entityType: userActivityLogs.entityType,
      entityId: userActivityLogs.entityId,
      details: userActivityLogs.details,
      createdAt: userActivityLogs.createdAt,
      userName: users.name,
    })
    .from(userActivityLogs)
    .leftJoin(users, eq(userActivityLogs.userId, users.id))
    .where(
      and(
        eq(userActivityLogs.entityType, "flock"),
        eq(userActivityLogs.entityId, flockId)
      )
    )
    .orderBy(desc(userActivityLogs.createdAt));

  return logs;
}

export async function getAllActivityLogs() {
  const db = await getDb();
  if (!db) return [];

  const logs = await db
    .select({
      id: userActivityLogs.id,
      userId: userActivityLogs.userId,
      action: userActivityLogs.action,
      entityType: userActivityLogs.entityType,
      entityId: userActivityLogs.entityId,
      details: userActivityLogs.details,
      createdAt: userActivityLogs.createdAt,
      userName: users.name,
    })
    .from(userActivityLogs)
    .leftJoin(users, eq(userActivityLogs.userId, users.id))
    .orderBy(desc(userActivityLogs.createdAt))
    .limit(1000); // Limit to last 1000 logs for performance

  return logs;
}

export async function createInvoice(data: {
  invoiceNumber: string;
  customerId: number;
  catchSessionId?: number;
  processorId?: number;
  invoiceDate: Date;
  dueDate: Date;
  pricePerKgExcl: number;
  totalBirds: number;
  totalWeight: number;
  vatPercentage: number;
  createdBy?: number;
  // Optional pre-computed totals (from line items); if provided, skip weight × price calculation
  exclusiveTotal?: number;
  vatAmount?: number;
  inclusiveTotal?: number;
}): Promise<{ insertId: number }> {
  const db = await getDb();

  // Use pre-computed totals if provided, otherwise calculate from weight × price
  const exclusiveTotal = data.exclusiveTotal ?? (data.totalWeight * data.pricePerKgExcl);
  const vatAmount = data.vatAmount ?? (exclusiveTotal * (data.vatPercentage / 100));
  const inclusiveTotal = data.inclusiveTotal ?? (exclusiveTotal + vatAmount);

  const result = await db.insert(invoices).values({
    invoiceNumber: data.invoiceNumber,
    customerId: data.customerId,
    invoiceDate: data.invoiceDate instanceof Date ? data.invoiceDate.toISOString().slice(0, 19).replace('T', ' ') : data.invoiceDate,
    dueDate: data.dueDate instanceof Date ? data.dueDate.toISOString().slice(0, 19).replace('T', ' ') : data.dueDate,
    subtotal: Math.round(exclusiveTotal * 100),
    taxAmount: Math.round(vatAmount * 100),
    totalAmount: Math.round(inclusiveTotal * 100),
    paidAmount: 0,
    balanceDue: Math.round(inclusiveTotal * 100),
    status: "draft",
    createdBy: data.createdBy,
    catchSessionId: data.catchSessionId,
    processorId: data.processorId,
    pricePerKgExcl: data.pricePerKgExcl,
    totalBirds: data.totalBirds,
    totalWeight: data.totalWeight,
    exclusiveTotal,
    vatAmount,
    inclusiveTotal,
    vatPercentage: data.vatPercentage,
  });

  return { insertId: Number(result.insertId) };
}


export async function getInvoiceByNumber(invoiceNumber: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(invoices).where(eq(invoices.invoiceNumber, invoiceNumber)).limit(1);
  return result[0] || null;
}

export async function markInvoiceAsSent(invoiceId: number, sentAt: string) {
  const db = await getDb();
  if (!db) return null;
  await db.update(invoices)
    .set({ status: 'sent', sentAt, updatedAt: new Date().toISOString().slice(0, 19).replace('T', ' ') })
    .where(eq(invoices.id, invoiceId));
  return { success: true };
}

export async function recordInvoicePayment(invoiceId: number, data: {
  amount: number;
  paymentMethod: string;
  paymentDate: string;
}) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(invoices).where(eq(invoices.id, invoiceId)).limit(1);
  const invoice = rows[0];
  if (!invoice) throw new Error('Invoice not found');
  const totalAmount = invoice.totalAmount;
  const currentPaid = invoice.paidAmount || 0;
  const newPaid = currentPaid + Math.round(data.amount * 100);
  const newBalance = totalAmount - newPaid;
  const newStatus = newBalance <= 0 ? 'paid' : 'partial';
  await db.update(invoices)
    .set({
      paidAmount: newPaid,
      balanceDue: Math.max(0, newBalance),
      status: newStatus as 'paid' | 'partial',
      paymentMethod: data.paymentMethod,
      paymentDate: data.paymentDate,
      updatedAt: new Date().toISOString().slice(0, 19).replace('T', ' '),
    })
    .where(eq(invoices.id, invoiceId));
  return { success: true, newStatus, newPaid, newBalance: Math.max(0, newBalance) };
}

export async function cancelInvoice(invoiceId: number) {
  const db = await getDb();
  if (!db) return null;
  await db.update(invoices)
    .set({ status: 'cancelled', updatedAt: new Date().toISOString().slice(0, 19).replace('T', ' ') })
    .where(eq(invoices.id, invoiceId));
  return { success: true };
}

export async function getCatchSessionById(catchSessionId: number) {
  const db = await getDb();
  const result = await db
    .select()
    .from(catchSessions)
    .where(eq(catchSessions.id, catchSessionId))
    .limit(1);
  
  return result[0] || null;
}


// ============================================================================
// COMPANY SETTINGS
// ============================================================================

export async function getCompanySettings() {
  const db = await getDb();
  const result = await db.query.companySettings.findFirst();
  return result || null;
}

export async function updateCompanySettings(data: any, userId: number) {
  const db = await getDb();
  const existing = await db.query.companySettings.findFirst();
  
  // Build explicit update payload from known schema fields
  const updatePayload: any = {};
  
  // Only include fields that are defined in the schema
  if (data.companyName !== undefined) updatePayload.companyName = data.companyName;
  if (data.vatNumber !== undefined) updatePayload.vatNumber = data.vatNumber;
  if (data.registrationNumber !== undefined) updatePayload.registrationNumber = data.registrationNumber;
  if (data.address !== undefined) updatePayload.address = data.address;
  if (data.phone !== undefined) updatePayload.phone = data.phone;
  if (data.email !== undefined) updatePayload.email = data.email;
  if (data.website !== undefined) updatePayload.website = data.website;
  if (data.bankName !== undefined) updatePayload.bankName = data.bankName;
  if (data.branchCode !== undefined) updatePayload.branchCode = data.branchCode;
  if (data.accountName !== undefined) updatePayload.accountName = data.accountName;
  if (data.accountNumber !== undefined) updatePayload.accountNumber = data.accountNumber;
  if (data.accountReference !== undefined) updatePayload.accountReference = data.accountReference;
  if (data.logoUrl !== undefined) updatePayload.logoUrl = data.logoUrl;
  if (data.timezone !== undefined) updatePayload.timezone = data.timezone;
  
  if (existing) {
    return await db
      .update(companySettings)
      .set(updatePayload)
      .where(eq(companySettings.id, existing.id));
  } else {
    return await db.insert(companySettings).values({
      ...updatePayload,
      createdBy: userId,
    });
  }
}


// ============================================================================
// SCHEDULED TASKS: INVOICE STATUS MANAGEMENT
// ============================================================================

/**
 * Flag invoices as overdue if:
 * - Status is 'sent' or 'partial' (not yet fully paid)
 * - Due date has passed (dueDate < now)
 * Returns count of updated invoices
 */
export async function flagOverdueInvoices(now: Date): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  
  const result = await db.update(invoices)
    .set({ 
      status: 'overdue',
      updatedAt: new Date().toISOString().slice(0, 19).replace('T', ' ')
    })
    .where(
      and(
        inArray(invoices.status, ['sent', 'partial']),
        lt(invoices.dueDate, now.toISOString().slice(0, 19).replace('T', ' '))
      )
    );
  
  return result.rowsAffected || 0;
}

/**
 * Revert invoices from 'overdue' back to 'paid' if:
 * - Status is 'overdue'
 * - paidAmount >= inclusiveTotal (fully paid)
 * Returns count of updated invoices
 */
export async function revertPaidFromOverdue(): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  
  // Fetch all overdue invoices
  const overdueInvoices = await db
    .select()
    .from(invoices)
    .where(eq(invoices.status, 'overdue'));
  
  let count = 0;
  for (const invoice of overdueInvoices) {
    const paidAmount = invoice.paidAmount || 0;
    const inclusiveTotal = invoice.inclusiveTotal ? parseFloat(String(invoice.inclusiveTotal)) * 100 : 0;
    
    if (paidAmount >= inclusiveTotal) {
      await db.update(invoices)
        .set({ 
          status: 'paid',
          updatedAt: new Date().toISOString().slice(0, 19).replace('T', ' ')
        })
        .where(eq(invoices.id, invoice.id));
      count++;
    }
  }
  
  return count;
}


// ============================================================================
// FINANCIAL MANAGEMENT: EXPENSE TRACKING
// ============================================================================

export async function getExpenseCategories() {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(expenseCategories)
    .where(eq(expenseCategories.isActive, 1))
    .orderBy(expenseCategories.name);
}

export async function createExpense(data: {
  categoryId: number;
  houseId?: number;
  flockId?: number;
  description: string;
  amount: number;
  vatPercentage?: number;
  expenseDate: string;
  paymentMethod?: string;
  reference?: string;
  notes?: string;
  createdBy?: number;
}) {
  const db = await getDb();
  if (!db) return null;
  const vatPct = data.vatPercentage || 15;
  const vatAmount = Math.round(data.amount * (vatPct / 100));
  const totalAmount = data.amount + vatAmount;
  return await db.insert(expenses).values({
    categoryId: data.categoryId,
    houseId: data.houseId,
    flockId: data.flockId,
    description: data.description,
    amount: data.amount,
    vatAmount,
    totalAmount,
    vatPercentage: vatPct.toString(),
    expenseDate: data.expenseDate,
    paymentMethod: data.paymentMethod,
    reference: data.reference,
    notes: data.notes,
    createdBy: data.createdBy,
    status: 'pending',
  });
}

export async function listExpenses(filters?: {
  categoryId?: number;
  houseId?: number;
  flockId?: number;
  status?: string;
  startDate?: string;
  endDate?: string;
  limit?: number;
  offset?: number;
}) {
  const db = await getDb();
  if (!db) return { expenses: [], total: 0 };
  const conditions: any[] = [];
  if (filters?.categoryId) conditions.push(eq(expenses.categoryId, filters.categoryId));
  if (filters?.houseId) conditions.push(eq(expenses.houseId, filters.houseId));
  if (filters?.flockId) conditions.push(eq(expenses.flockId, filters.flockId));
  if (filters?.status) conditions.push(eq(expenses.status, filters.status as any));
  if (filters?.startDate) conditions.push(gte(expenses.expenseDate, filters.startDate));
  if (filters?.endDate) conditions.push(lte(expenses.expenseDate, filters.endDate));
  const whereClause = conditions.length > 0 ? and(...conditions) : undefined;
  const result = await db.select().from(expenses)
    .where(whereClause)
    .orderBy(desc(expenses.expenseDate))
    .limit(filters?.limit || 100)
    .offset(filters?.offset || 0);
  return { expenses: result, total: result.length };
}

export async function updateExpenseStatus(expenseId: number, status: 'pending' | 'paid' | 'overdue' | 'cancelled', paymentDate?: string) {
  const db = await getDb();
  if (!db) return null;
  const updateData: any = {
    status,
    updatedAt: new Date().toISOString().slice(0, 19).replace('T', ' ')
  };
  if (paymentDate && status === 'paid') updateData.paymentDate = paymentDate;
  return await db.update(expenses).set(updateData).where(eq(expenses.id, expenseId));
}

export async function getExpenseSummary(startDate?: string, endDate?: string) {
  const db = await getDb();
  if (!db) return { totalExpenses: 0, totalByCategory: [] };
  const conditions: any[] = [];
  if (startDate) conditions.push(gte(expenses.expenseDate, startDate));
  if (endDate) conditions.push(lte(expenses.expenseDate, endDate));
  const whereClause = conditions.length > 0 ? and(...conditions) : undefined;
  const result = await db.select({
    categoryName: expenseCategories.name,
    totalAmount: sql<number>`SUM(${expenses.totalAmount})`,
    count: sql<number>`COUNT(*)`,
  })
    .from(expenses)
    .innerJoin(expenseCategories, eq(expenses.categoryId, expenseCategories.id))
    .where(whereClause)
    .groupBy(expenses.categoryId);
  const totalExpenses = result.reduce((sum, row) => sum + (row.totalAmount || 0), 0);
  return { totalExpenses, totalByCategory: result };
}

// ============================================================================
// FINANCIAL MANAGEMENT: CASH FLOW FORECASTING
// ============================================================================

export async function createCashFlowForecast(data: {
  startDate: string;
  endDate: string;
  notes?: string;
  createdBy?: number;
}) {
  const db = await getDb();
  if (!db) return null;
  return await db.insert(cashFlowForecasts).values({
    forecastDate: new Date().toISOString().slice(0, 19).replace('T', ' '),
    startDate: data.startDate,
    endDate: data.endDate,
    notes: data.notes,
    createdBy: data.createdBy,
  });
}

export async function addCashFlowItem(data: {
  forecastId: number;
  itemDate: string;
  itemType: 'income' | 'expense';
  category: string;
  description: string;
  amount: number;
  houseId?: number;
  flockId?: number;
  relatedExpenseId?: number;
  notes?: string;
}) {
  const db = await getDb();
  if (!db) return null;
  return await db.insert(cashFlowItems).values({
    forecastId: data.forecastId,
    itemDate: data.itemDate,
    itemType: data.itemType,
    category: data.category,
    description: data.description,
    amount: data.amount,
    houseId: data.houseId,
    flockId: data.flockId,
    relatedExpenseId: data.relatedExpenseId,
    notes: data.notes,
  });
}

export async function getCashFlowForecast(forecastId: number) {
  const db = await getDb();
  if (!db) return null;
  const forecast = await db.select().from(cashFlowForecasts).where(eq(cashFlowForecasts.id, forecastId)).limit(1);
  if (!forecast.length) return null;
  const items = await db.select().from(cashFlowItems).where(eq(cashFlowItems.forecastId, forecastId)).orderBy(cashFlowItems.itemDate);
  return { forecast: forecast[0], items };
}

export async function calculateCashFlowSummary(forecastId: number) {
  const db = await getDb();
  if (!db) return { totalIncome: 0, totalExpense: 0, netCashFlow: 0, dailyBalance: [] };
  const items = await db.select().from(cashFlowItems).where(eq(cashFlowItems.forecastId, forecastId)).orderBy(cashFlowItems.itemDate);
  let totalIncome = 0;
  let totalExpense = 0;
  let runningBalance = 0;
  const dailyBalance: Array<{ date: string; balance: number; income: number; expense: number }> = [];
  let currentDate = '';
  let dayIncome = 0;
  let dayExpense = 0;
  for (const item of items) {
    const itemDate = item.itemDate.split(' ')[0];
    if (currentDate && itemDate !== currentDate) {
      runningBalance = runningBalance + dayIncome - dayExpense;
      dailyBalance.push({ date: currentDate, balance: runningBalance, income: dayIncome, expense: dayExpense });
      dayIncome = 0;
      dayExpense = 0;
    }
    currentDate = itemDate;
    if (item.itemType === 'income') { totalIncome += item.amount; dayIncome += item.amount; }
    else { totalExpense += item.amount; dayExpense += item.amount; }
  }
  if (currentDate) {
    runningBalance = runningBalance + dayIncome - dayExpense;
    dailyBalance.push({ date: currentDate, balance: runningBalance, income: dayIncome, expense: dayExpense });
  }
  return { totalIncome, totalExpense, netCashFlow: totalIncome - totalExpense, dailyBalance };
}

export async function listCashFlowForecasts(limit = 10, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(cashFlowForecasts).orderBy(desc(cashFlowForecasts.forecastDate)).limit(limit).offset(offset);
}


// ============================================================================
// FEED MANAGEMENT — FORMULATIONS
// ============================================================================

export async function createFeedFormulation(data: {
  name: string;
  feedRange: 'premium' | 'value' | 'econo';
  feedStage: 'starter' | 'grower' | 'finisher';
  version?: number;
  description?: string;
  ingredients: string;
  proteinPercentage?: string;
  energyContent?: string;
  crudeProtein?: string;
  crudeFiber?: string;
  calcium?: string;
  phosphorus?: string;
  macroKgPerTon?: string;
  soyaOilKgPerTon?: string;
  probioticKgPerTon?: string;
  allocationKgPerBird?: string;
  effectiveDate?: string;
  isActive?: number;
  createdBy?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  const result = await db.insert(feedFormulations).values({
    name: data.name,
    feedRange: data.feedRange,
    feedStage: data.feedStage,
    version: data.version ?? 1,
    description: data.description,
    ingredients: data.ingredients,
    proteinPercentage: data.proteinPercentage,
    energyContent: data.energyContent,
    crudeProtein: data.crudeProtein,
    crudeFiber: data.crudeFiber,
    calcium: data.calcium,
    phosphorus: data.phosphorus,
    macroKgPerTon: data.macroKgPerTon,
    soyaOilKgPerTon: data.soyaOilKgPerTon,
    probioticKgPerTon: data.probioticKgPerTon,
    allocationKgPerBird: data.allocationKgPerBird,
    effectiveDate: data.effectiveDate,
    isActive: data.isActive ?? 1,
    createdBy: data.createdBy,
  });
  return Number((result as any)[0]?.insertId ?? (result as any).insertId ?? 0);
}

export async function deactivateFeedFormulation(id: number) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  await db.update(feedFormulations).set({ isActive: 0 }).where(eq(feedFormulations.id, id));
}

// ============================================================================
// FEED MANAGEMENT — MILL COSTS
// ============================================================================

export async function listMillCosts(filters?: {
  feedRange?: 'premium' | 'value' | 'econo';
  feedType?: 'starter' | 'grower' | 'finisher';
}) {
  const db = await getDb();
  if (!db) return [];
  const conditions: ReturnType<typeof eq>[] = [];
  if (filters?.feedRange) conditions.push(eq(millCosts.feedRange, filters.feedRange));
  if (filters?.feedType) conditions.push(eq(millCosts.feedType, filters.feedType));
  const query = db.select().from(millCosts).orderBy(desc(millCosts.effectiveDate));
  if (conditions.length > 0) {
    return await query.where(and(...conditions));
  }
  return await query;
}

export async function getMillCost(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(millCosts).where(eq(millCosts.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function createMillCost(data: {
  feedRange: 'premium' | 'value' | 'econo';
  feedType: 'starter' | 'grower' | 'finisher';
  costPerTon: string;
  effectiveDate: string;
  notes?: string;
  createdBy?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  const result = await db.insert(millCosts).values({
    feedRange: data.feedRange,
    feedType: data.feedType,
    costPerTon: data.costPerTon,
    effectiveDate: data.effectiveDate,
    notes: data.notes,
    createdBy: data.createdBy,
  });
  return Number((result as any)[0]?.insertId ?? (result as any).insertId ?? 0);
}

export async function updateMillCost(id: number, data: {
  costPerTon?: string;
  effectiveDate?: string;
  notes?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  const updateData: Record<string, unknown> = {};
  if (data.costPerTon !== undefined) updateData.costPerTon = data.costPerTon;
  if (data.effectiveDate !== undefined) updateData.effectiveDate = data.effectiveDate;
  if (data.notes !== undefined) updateData.notes = data.notes;
  await db.update(millCosts).set(updateData).where(eq(millCosts.id, id));
}

export async function deleteMillCost(id: number) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  await db.delete(millCosts).where(eq(millCosts.id, id));
}

// ============================================================================
// FEED MANAGEMENT — CUSTOMER FEED PRICES
// ============================================================================

export async function listCustomerFeedPrices(filters?: {
  customerId?: number;
  feedRange?: 'premium' | 'value' | 'econo';
  feedType?: 'starter' | 'grower' | 'finisher';
}) {
  const db = await getDb();
  if (!db) return [];
  const conditions: ReturnType<typeof eq>[] = [];
  if (filters?.customerId) conditions.push(eq(customerFeedPrices.customerId, filters.customerId));
  if (filters?.feedRange) conditions.push(eq(customerFeedPrices.feedRange, filters.feedRange));
  if (filters?.feedType) conditions.push(eq(customerFeedPrices.feedType, filters.feedType));
  // Join with customers to get customer name
  const query = db
    .select({
      id: customerFeedPrices.id,
      customerId: customerFeedPrices.customerId,
      customerName: customers.name,
      feedRange: customerFeedPrices.feedRange,
      feedType: customerFeedPrices.feedType,
      pricePerTon: customerFeedPrices.pricePerTon,
      effectiveDate: customerFeedPrices.effectiveDate,
      notes: customerFeedPrices.notes,
      createdAt: customerFeedPrices.createdAt,
    })
    .from(customerFeedPrices)
    .leftJoin(customers, eq(customerFeedPrices.customerId, customers.id))
    .orderBy(desc(customerFeedPrices.effectiveDate));
  if (conditions.length > 0) {
    return await query.where(and(...conditions));
  }
  return await query;
}

export async function getCustomerFeedPrice(id: number) {
  const db = await getDb();
  if (!db) return null;
  const rows = await db.select().from(customerFeedPrices).where(eq(customerFeedPrices.id, id)).limit(1);
  return rows[0] ?? null;
}

export async function createCustomerFeedPrice(data: {
  customerId: number;
  feedRange: 'premium' | 'value' | 'econo';
  feedType: 'starter' | 'grower' | 'finisher';
  pricePerTon: string;
  effectiveDate: string;
  notes?: string;
  createdBy?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  const result = await db.insert(customerFeedPrices).values({
    customerId: data.customerId,
    feedRange: data.feedRange,
    feedType: data.feedType,
    pricePerTon: data.pricePerTon,
    effectiveDate: data.effectiveDate,
    notes: data.notes,
    createdBy: data.createdBy,
  });
  return Number((result as any)[0]?.insertId ?? (result as any).insertId ?? 0);
}

export async function updateCustomerFeedPrice(id: number, data: {
  pricePerTon?: string;
  effectiveDate?: string;
  notes?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  const updateData: Record<string, unknown> = {};
  if (data.pricePerTon !== undefined) updateData.pricePerTon = data.pricePerTon;
  if (data.effectiveDate !== undefined) updateData.effectiveDate = data.effectiveDate;
  if (data.notes !== undefined) updateData.notes = data.notes;
  await db.update(customerFeedPrices).set(updateData).where(eq(customerFeedPrices.id, id));
}

export async function deleteCustomerFeedPrice(id: number) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  await db.delete(customerFeedPrices).where(eq(customerFeedPrices.id, id));
}
